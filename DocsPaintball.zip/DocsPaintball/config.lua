Config = {}

Config.JoinZone = {
    coords = vector3(-243.63, -2029.09, 28.95),
    radius = 3.0,
    markerType = 1,
    markerColor = { r = 255, g = 100, b = 100, a = 150 },
    text = '~g~[E]~s~ Paintball Lobby'
}

Config.NPC = {
    enabled = true,
    coords = vec4(-243.63, -2029.09, 28.95, 226.02),
    -- NPC ped model. The default here is s_m_y_blackops_01 which represents a
    -- SWAT/Black Ops soldier. You can change this to any valid ped model.
    model = 's_m_y_blackops_01',
    -- The distance within which the ox_target eye will appear for the NPC.
    targetDistance = 2.0
}

-- Multiple paintball arenas/maps
Config.Maps = {
    [1] = {
        name = "Grove Street",
        description = "Classic neighborhood street combat",
        redTeamSpawns = {
            vector3(85.42, -1972.32, 20.78),
            vector3(89.85, -1966.49, 20.75),
            vector3(121.22, -1926.86, 20.99)
        },
        blueTeamSpawns = {
            vector3(40.5, -1923.71, 21.67),
            vector3(79.79, -1894.01, 22.21),
            vector3(46.77, -1917.43, 21.68)
        },
        centre = vector3(84.34, -1923.09, 20.84)
    },
    [2] = {
        name = "Airport Hangar",
        description = "Large open hangar with aircraft cover",
        redTeamSpawns = {
            vector3(-1336.89, -3044.17, 13.94),
            vector3(-1350.23, -3040.45, 13.94),
            vector3(-1360.12, -3035.78, 13.94)
        },
        blueTeamSpawns = {
            vector3(-1266.45, -3013.67, 13.94),
            vector3(-1280.34, -3008.91, 13.94),
            vector3(-1290.67, -3015.23, 13.94)
        },
        centre = vector3(-1313.67, -3029.42, 13.94)
    },
    [3] = {
        name = "Sandy Shores Airfield",
        description = "Desert combat with plane obstacles",
        redTeamSpawns = {
            vector3(1747.52, 3273.84, 41.13),
            vector3(1755.67, 3280.12, 41.13),
            vector3(1762.34, 3285.45, 41.13)
        },
        blueTeamSpawns = {
            vector3(1692.78, 3230.45, 41.13),
            vector3(1685.23, 3225.67, 41.13),
            vector3(1678.91, 3220.34, 41.13)
        },
        centre = vector3(1720.65, 3252.65, 41.13)
    },
    [4] = {
        name = "Warehouse District",
        description = "Industrial close-quarters combat",
        redTeamSpawns = {
            vector3(1201.45, -3253.67, 5.79),
            vector3(1208.23, -3248.91, 5.79),
            vector3(1215.67, -3244.12, 5.79)
        },
        blueTeamSpawns = {
            vector3(1165.34, -3210.45, 5.79),
            vector3(1158.67, -3205.23, 5.79),
            vector3(1151.23, -3200.67, 5.79)
        },
        centre = vector3(1183.39, -3226.89, 5.79)
    }
}

-- Default arena (for backwards compatibility)
Config.Arena = Config.Maps[1]

Config.GameSettings = {
    killLimit = 20,
    timeLimit = 300,    -- 5 minutes (in seconds)
    respawnDelay = 5,   -- seconds
    joinCooldown = 10   -- seconds to prevent spamming join
}

-- Team-specific configurations
Config.Teams = {
    [1] = { -- Red Team
        name = "Red Team",
        color = "#ff0040",
        radioFrequency = 300,
        outfit = {
            male = {
                ['tshirt_1'] = 15,   ['tshirt_2'] = 0,    -- White undershirt
                ['torso_1'] = 61,    ['torso_2'] = 1,     -- Red sports jacket
                ['arms'] = 4,                             -- Red arms
                ['pants_1'] = 9,     ['pants_2'] = 1,     -- Red track pants
                ['shoes_1'] = 12,    ['shoes_2'] = 6,     -- Red sneakers
                ['helmet_1'] = 18,   ['helmet_2'] = 1,    -- Red cap
                ['mask_1'] = 0,      ['mask_2'] = 0,      -- No mask
                ['chain_1'] = 0,     ['chain_2'] = 0,
                ['ears_1'] = -1,     ['ears_2'] = 0,
                ['bags_1'] = 0,      ['bags_2'] = 0,
                ['bproof_1'] = 0,    ['bproof_2'] = 0
            },
            female = {
                ['tshirt_1'] = 14,   ['tshirt_2'] = 0,    -- White undershirt
                ['torso_1'] = 73,    ['torso_2'] = 1,     -- Red sports top
                ['arms'] = 4,                             -- Red arms
                ['pants_1'] = 16,    ['pants_2'] = 1,     -- Red track pants
                ['shoes_1'] = 12,    ['shoes_2'] = 6,     -- Red sneakers
                ['helmet_1'] = 17,   ['helmet_2'] = 1,    -- Red cap
                ['mask_1'] = 0,      ['mask_2'] = 0,      -- No mask
                ['chain_1'] = 0,     ['chain_2'] = 0,
                ['ears_1'] = -1,     ['ears_2'] = 0,
                ['bags_1'] = 0,      ['bags_2'] = 0,
                ['bproof_1'] = 0,    ['bproof_2'] = 0
            }
        }
    },
    [2] = { -- Blue Team
        name = "Blue Team",
        color = "#0080ff",
        radioFrequency = 400,
        outfit = {
            male = {
                ['tshirt_1'] = 15,   ['tshirt_2'] = 0,    -- White undershirt
                ['torso_1'] = 61,    ['torso_2'] = 3,     -- Blue sports jacket
                ['arms'] = 1,                             -- Blue arms
                ['pants_1'] = 9,     ['pants_2'] = 3,     -- Blue track pants
                ['shoes_1'] = 12,    ['shoes_2'] = 11,    -- Blue sneakers
                ['helmet_1'] = 18,   ['helmet_2'] = 3,    -- Blue cap
                ['mask_1'] = 0,      ['mask_2'] = 0,      -- No mask
                ['chain_1'] = 0,     ['chain_2'] = 0,
                ['ears_1'] = -1,     ['ears_2'] = 0,
                ['bags_1'] = 0,      ['bags_2'] = 0,
                ['bproof_1'] = 0,    ['bproof_2'] = 0
            },
            female = {
                ['tshirt_1'] = 14,   ['tshirt_2'] = 0,    -- White undershirt
                ['torso_1'] = 73,    ['torso_2'] = 3,     -- Blue sports top
                ['arms'] = 4,                             -- Blue arms
                ['pants_1'] = 16,    ['pants_2'] = 3,     -- Blue track pants
                ['shoes_1'] = 12,    ['shoes_2'] = 11,    -- Blue sneakers
                ['helmet_1'] = 17,   ['helmet_2'] = 0,    -- Blue cap
                ['mask_1'] = 0,      ['mask_2'] = 0,      -- No mask
                ['chain_1'] = 0,     ['chain_2'] = 0,
                ['ears_1'] = -1,     ['ears_2'] = 0,
                ['bags_1'] = 0,      ['bags_2'] = 0,
                ['bproof_1'] = 0,    ['bproof_2'] = 0
            }
        }
    }
}

Config.Rewards = {
    -- Individual reward toggles - set to false to disable specific reward types
    KillRewardEnabled = true,        -- Enable/disable kill rewards
    CompletionBonusEnabled = false,   -- Enable/disable match completion bonus
    WinnerBonusEnabled = false,       -- Enable/disable winner bonus

    -- Money reward per kill: {min, max} - players get a random amount between these values
    KillReward = {400, 600}, -- Min: 400, Max: 600 per kill

    -- Match completion bonus: {min, max} - given to all players when match ends
    CompletionBonus = {1000, 2000}, -- Min: 1000, Max: 2000 for completing a match

    -- Winner bonus: {min, max} - additional bonus for winning team members
    WinnerBonus = {3000, 5000} -- Min: 3000, Max: 5000 extra for winning team
}

-- Police/Dispatch Settings
Config.DisablePoliceAlerts = {
    Enabled = false,                 -- DISABLED: Prevents serialization errors with emergency alerts
    DisableDispatch = true,          -- Disable ps-dispatch alerts
    DisableMDTAlerts = true,         -- Disable MDT alerts
    DisableGunshots = true,          -- Disable gunshot alerts
    DisableDeathAlerts = true,       -- Disable death/injury alerts
    DisableOfficerDown = true,       -- Disable officer down alerts
    DisableEMSAlerts = true,         -- Disable EMS/ambulance alerts
    DisableAllEmergencyAlerts = true, -- Disable all emergency service alerts
}

-- Weapon System Settings
Config.WeaponSystem = {
    UseServerWeapons = false,         -- Try to get weapons from server items first
    FallbackToConfig = true,         -- Use config weapons if server weapons not found
    FilterWeaponTypes = true,        -- Only include actual weapons (not melee/throwables)
    DefaultAmmo = 2000,              -- Default ammo amount for server weapons
}

Config.Weapons = {
    {
        label = 'Pistol',
        hash = 'WEAPON_PISTOL',
        ammo = 2000
    },
    {
        label = 'Pistol Mk II',
        hash = 'WEAPON_PISTOL_MK2',
        ammo = 2000
    },
    {
        label = 'AP Pistol',
        hash = 'WEAPON_APPISTOL',
        ammo = 2000
    },
    {
        label = 'SMG',
        hash = 'WEAPON_SMG',
        ammo = 2000
    },
    {
        label = 'MINIGUN',
        hash = 'WEAPON_MINIGUN',
        ammo = 5000
    }
}

-- Maximum number of players allowed per match. Teams will be split as
-- evenly as possible. If too many players join the lobby the extra
-- players will wait until the next round.
Config.MaxPlayers = 12

-- All-time statistics tracking
Config.AllTimeStats = {
    Enabled = true,                    -- Enable persistent stat tracking
    UseDatabase = false,               -- Set to true to use database (requires oxmysql)
    DatabaseTable = 'paintball_stats', -- Table name for database storage
    UsePlayerData = true,              -- Use QBCore player data for storage (recommended)
    ResetStatsCommand = 'resetpaintballstats' -- Admin command to reset all stats
}