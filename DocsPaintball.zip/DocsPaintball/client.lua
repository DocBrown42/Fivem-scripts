-- client.lua
-- Client side logic for the paintball mini‑game. Handles interaction with
-- the game world (markers and prompts), opens the NUI lobby, manages
-- player death/respawn, weapon handling and scoreboard updates.

local QBCore = exports['qb-core']:GetCoreObject()

-- State variables
local inLobby = false
local inGame = false
local isHost = false
local team = 0
local spawnCoords = nil
local killLimit = 0
local timeLimit = 0
local scoreboard = { teamKills = { [1] = 0, [2] = 0 }, individual = {} }
local remainingTime = 0
local lastDeathTime = 0
local joinCooldown = 0
local savedPosition = nil
local savedHeading = nil
local savedWeapon = nil
local savedWeaponAmmo = 0

-- Stores the currently selected paintball weapon for this match. This
-- is populated when the match begins (in qb-paintball:startGame) and
-- used when respawning so players receive the same weapon after death.
-- The table contains the fields { hash, ammo }. Tints are no longer
-- applied by default to avoid conflicts with ox_inventory. If you
-- decide to use tints again, add a `tint` property here.
local currentWeapon = nil

-- Stores the player's original outfit before the match starts
local savedOutfit = nil

-- Stores the current map being used for the match
local currentMap = nil

-- Dynamic weapons system
local availableWeapons = nil
local weaponsLoaded = false

-- Load weapons list when resource starts
CreateThread(function()
    -- Wait for QBCore to be ready
    while not QBCore do
        Wait(100)
    end

    -- Request weapons from server
    TriggerServerEvent('Docs-paintball:requestWeapons')
end)

-- Handle weapons list response from server
RegisterNetEvent('Docs-paintball:receiveWeapons', function(weapons)
    availableWeapons = weapons or Config.Weapons
    weaponsLoaded = true
end)

-- Handle detailed scoreboard from server
RegisterNetEvent('Docs-paintball:showDetailedScoreboard', function(scoreboard)
    print("📊 Received detailed scoreboard:", json.encode(scoreboard))
    SendNUIMessage({
        action = 'showDetailedScoreboard',
        scoreboard = scoreboard
    })
end)

-- Handle all-time stats from server
RegisterNetEvent('Docs-paintball:showAllTimeStats', function(leaderboard)
    print("🏆 Received all-time stats:", json.encode(leaderboard))
    SendNUIMessage({
        action = 'showAllTimeStats',
        leaderboard = leaderboard
    })
end)

-- Handle lobby members from server
RegisterNetEvent('Docs-paintball:receiveLobbyMembers', function(members, settings)
    print("👥 Received lobby members:", json.encode(members))
    SendNUIMessage({
        action = 'showLobbyMembers',
        members = members,
        settings = settings
    })
end)

-- Helper to convert weapon identifiers into numeric hashes. Config.Weapons
-- entries may provide either a backtick literal (number) or a string
-- weapon name (e.g. 'WEAPON_PISTOL'). This function ensures we always
-- use a numeric hash when giving weapons.
local function toWeaponHash(val)
    if not val then return nil end
    if type(val) == 'number' then
        return val
    end
    return GetHashKey(val)
end

-- Store the latest lobby settings received from the server. This is used to
-- reopen the lobby menu with the correct values after closing it. The
-- variable is updated whenever we receive a refreshLobby event or create/join
-- a lobby. When reopening the menu we fall back to this if no
-- lobbySettings argument is provided.
local lastLobbySettings = nil

-- If using an NPC instead of a marker, we define an event to open the lobby
-- menu when the player interacts with the NPC via ox_target. This event is
-- triggered from the ox_target interaction defined later. It simply opens
-- the lobby menu in the same way as pressing E in the marker would.
RegisterNetEvent('Docs-paintball:npcInteract', function(data)
    -- Only allow opening if we are not currently in a match. This prevents
    -- players from reopening the lobby menu mid‑match. Use our current
    -- isHost flag when opening so hosts see the proper controls. We pass
    -- through lastLobbySettings so the menu repopulates with the current
    -- lobby information when reopening after closing via the X button.
    if not inGame then
        openLobbyMenu(isHost, nil, scoreboard)
    end
end)

-- Helper: draw 3D text. Creates floating text at a world position. The
-- text scales with distance and displays for one frame; call every
-- tick when near the marker.
local function Draw3DText(x, y, z, text, scale)
    local onScreen, _x, _y = World3dToScreen2d(x, y, z)
    local px, py, pz = table.unpack(GetGameplayCamCoords())
    local dist = #(vector3(px, py, pz) - vector3(x, y, z))
    local s = (scale or 0.35) / dist
    local fov = (1 / GetGameplayCamFov()) * 100
    s = s * fov
    if onScreen then
        SetTextScale(0.0 * s, 0.35 * s)
        SetTextFont(4)
        SetTextProportional(true)
        SetTextColour(255, 255, 255, 215)
        SetTextDropshadow(0, 0, 0, 0, 255)
        SetTextEdge(2, 0, 0, 0, 150)
        SetTextDropShadow()
        SetTextOutline()
        SetTextEntry('STRING')
        AddTextComponentString(text)
        DrawText(_x, _y)
    end
end

-- Save the player's current position, heading and primary weapon. We
-- restore this information when the match ends. We only save the
-- currently equipped weapon to reduce complexity.
local function savePlayerState()
    local ped = PlayerPedId()
    savedPosition = GetEntityCoords(ped)
    savedHeading = GetEntityHeading(ped)
    local weaponHash = GetSelectedPedWeapon(ped)
    if weaponHash and weaponHash ~= 0 then
        savedWeapon = weaponHash
        savedWeaponAmmo = GetAmmoInPedWeapon(ped, weaponHash)
    else
        savedWeapon = nil
        savedWeaponAmmo = 0
    end

    -- Save outfit
    savedOutfit = {
        ['tshirt_1'] = GetPedDrawableVariation(ped, 8),
        ['tshirt_2'] = GetPedTextureVariation(ped, 8),
        ['torso_1'] = GetPedDrawableVariation(ped, 11),
        ['torso_2'] = GetPedTextureVariation(ped, 11),
        ['arms'] = GetPedDrawableVariation(ped, 3),
        ['pants_1'] = GetPedDrawableVariation(ped, 4),
        ['pants_2'] = GetPedTextureVariation(ped, 4),
        ['shoes_1'] = GetPedDrawableVariation(ped, 6),
        ['shoes_2'] = GetPedTextureVariation(ped, 6),
        ['helmet_1'] = GetPedPropIndex(ped, 0),
        ['helmet_2'] = GetPedPropTextureIndex(ped, 0),
        ['mask_1'] = GetPedDrawableVariation(ped, 1),
        ['mask_2'] = GetPedTextureVariation(ped, 1),
        ['chain_1'] = GetPedDrawableVariation(ped, 7),
        ['chain_2'] = GetPedTextureVariation(ped, 7),
        ['ears_1'] = GetPedPropIndex(ped, 2),
        ['ears_2'] = GetPedPropTextureIndex(ped, 2),
        ['bags_1'] = GetPedDrawableVariation(ped, 5),
        ['bags_2'] = GetPedTextureVariation(ped, 5),
        ['bproof_1'] = GetPedDrawableVariation(ped, 9),
        ['bproof_2'] = GetPedTextureVariation(ped, 9)
    }
    print("💾 Saved player state (position, weapon, outfit)")
end

-- Apply team outfit based on team number
local function applyTeamOutfit(teamNumber)
    local ped = PlayerPedId()
    local teamConfig = Config.Teams[teamNumber]

    if not teamConfig or not teamConfig.outfit then
        print(string.format("❌ No outfit config found for team %d", teamNumber))
        return
    end

    -- Determine gender
    local model = GetEntityModel(ped)
    local isMale = (model == GetHashKey("mp_m_freemode_01"))
    local outfit = isMale and teamConfig.outfit.male or teamConfig.outfit.female

    if not outfit then
        print(string.format("❌ No outfit found for gender in team %d", teamNumber))
        return
    end

    print(string.format("👕 Applying %s outfit", teamConfig.name))

    -- Apply clothing components
    SetPedComponentVariation(ped, 8, outfit['tshirt_1'], outfit['tshirt_2'], 0) -- Undershirt
    SetPedComponentVariation(ped, 11, outfit['torso_1'], outfit['torso_2'], 0) -- Torso
    SetPedComponentVariation(ped, 3, outfit['arms'], 0, 0) -- Arms
    SetPedComponentVariation(ped, 4, outfit['pants_1'], outfit['pants_2'], 0) -- Pants
    SetPedComponentVariation(ped, 6, outfit['shoes_1'], outfit['shoes_2'], 0) -- Shoes
    SetPedComponentVariation(ped, 1, outfit['mask_1'], outfit['mask_2'], 0) -- Mask
    SetPedComponentVariation(ped, 7, outfit['chain_1'], outfit['chain_2'], 0) -- Chain
    SetPedComponentVariation(ped, 5, outfit['bags_1'], outfit['bags_2'], 0) -- Bags
    SetPedComponentVariation(ped, 9, outfit['bproof_1'], outfit['bproof_2'], 0) -- Body armor

    -- Apply props
    if outfit['helmet_1'] and outfit['helmet_1'] ~= -1 then
        SetPedPropIndex(ped, 0, outfit['helmet_1'], outfit['helmet_2'], true) -- Helmet
    else
        ClearPedProp(ped, 0)
    end

    if outfit['ears_1'] and outfit['ears_1'] ~= -1 then
        SetPedPropIndex(ped, 2, outfit['ears_1'], outfit['ears_2'], true) -- Ears
    else
        ClearPedProp(ped, 2)
    end
end

-- Restore the player's weapon and outfit if we saved them previously.
local function restorePlayerWeapon()
    local ped = PlayerPedId()

    -- Restore weapon
    if savedWeapon then
        GiveWeaponToPed(ped, savedWeapon, savedWeaponAmmo or 0, false, false)
        SetCurrentPedWeapon(ped, savedWeapon, true)
    end
    savedWeapon = nil
    savedWeaponAmmo = 0

    -- Restore outfit with enhanced reliability
    if savedOutfit then
        local model = GetEntityModel(ped)
        local isMale = (model == GetHashKey("mp_m_freemode_01"))
        local gender = isMale and "male" or "female"

        print(string.format("👕 Restoring original %s outfit", gender))
        print(string.format("🔍 Saved outfit data: %s", json.encode(savedOutfit)))

        -- Apply components with small delays for reliability
        SetPedComponentVariation(ped, 8, savedOutfit['tshirt_1'], savedOutfit['tshirt_2'], 0)
        Citizen.Wait(25)
        SetPedComponentVariation(ped, 11, savedOutfit['torso_1'], savedOutfit['torso_2'], 0)
        Citizen.Wait(25)
        SetPedComponentVariation(ped, 3, savedOutfit['arms'], 0, 0)
        Citizen.Wait(25)
        SetPedComponentVariation(ped, 4, savedOutfit['pants_1'], savedOutfit['pants_2'], 0)
        Citizen.Wait(25)
        SetPedComponentVariation(ped, 6, savedOutfit['shoes_1'], savedOutfit['shoes_2'], 0)
        Citizen.Wait(25)
        SetPedComponentVariation(ped, 1, savedOutfit['mask_1'], savedOutfit['mask_2'], 0)
        Citizen.Wait(25)
        SetPedComponentVariation(ped, 7, savedOutfit['chain_1'], savedOutfit['chain_2'], 0)
        Citizen.Wait(25)
        SetPedComponentVariation(ped, 5, savedOutfit['bags_1'], savedOutfit['bags_2'], 0)
        Citizen.Wait(25)
        SetPedComponentVariation(ped, 9, savedOutfit['bproof_1'], savedOutfit['bproof_2'], 0)

        -- Restore props
        Citizen.Wait(50)
        if savedOutfit['helmet_1'] and savedOutfit['helmet_1'] ~= -1 then
            SetPedPropIndex(ped, 0, savedOutfit['helmet_1'], savedOutfit['helmet_2'], true)
        else
            ClearPedProp(ped, 0)
        end

        Citizen.Wait(25)
        if savedOutfit['ears_1'] and savedOutfit['ears_1'] ~= -1 then
            SetPedPropIndex(ped, 2, savedOutfit['ears_1'], savedOutfit['ears_2'], true)
        else
            ClearPedProp(ped, 2)
        end

        -- Comprehensive skin reload for females especially
        Citizen.Wait(500)
        print("🔄 Triggering comprehensive skin reload...")

        -- Try multiple clothing systems
        pcall(function()
            TriggerEvent('qb-clothing:client:reloadSkin')
        end)

        Citizen.Wait(200)
        pcall(function()
            TriggerEvent('illenium-appearance:client:reloadSkin')
        end)

        Citizen.Wait(200)
        pcall(function()
            TriggerEvent('fivem-appearance:reloadSkin')
        end)

        Citizen.Wait(200)
        pcall(function()
            TriggerServerEvent('qb-clothing:loadPlayerSkin')
        end)

        Citizen.Wait(200)
        pcall(function()
            TriggerEvent('skinchanger:loadSkin', savedOutfit)
        end)

        print(string.format("✅ %s outfit restoration completed with full reload", gender))
    end
    savedOutfit = nil
end

-- Set radio frequency for team
local function setTeamRadio(teamNumber)
    local teamConfig = Config.Teams[teamNumber]

    if not teamConfig or not teamConfig.radioFrequency then
        print(string.format("❌ No radio frequency config found for team %d", teamNumber))
        return
    end

    local frequency = teamConfig.radioFrequency
    print(string.format("📻 Setting %s radio to frequency %d", teamConfig.name, frequency))

    -- Try different radio systems
    pcall(function()
        -- pma-voice radio
        exports['pma-voice']:setRadioChannel(frequency)
    end)

    pcall(function()
        -- saltychat radio
        exports['saltychat']:SetRadioChannel(frequency, true)
    end)

    pcall(function()
        -- qb-radio
        TriggerEvent('qb-radio:client:JoinRadioChannel', frequency)
    end)

    pcall(function()
        -- rp-radio
        exports['rp-radio']:SetRadioChannel(frequency)
    end)
end

-- Resurrect the local player at the stored spawn coordinates. Called
-- when the client detects they have died during a match. After
-- respawning we re‑equip the paintball weapon.
local function respawnPlayer()
    print("🔄 respawnPlayer called")
    local ped = PlayerPedId()
    if not spawnCoords then
        print("❌ No spawn coordinates available")
        return
    end
    print(string.format("🔄 Respawning at: %s", json.encode(spawnCoords)))
    -- Fade out and in for a smoother respawn
    DoScreenFadeOut(300)
    while not IsScreenFadedOut() do Citizen.Wait(50) end
    -- Choose a new spawn point from the team's spawn list. This
    -- prevents players from always respawning at the exact same
    -- location during a match. We determine the appropriate spawn
    -- list based on the player's current team assignment and pick a
    -- random entry. If for some reason the team is not set, fall
    -- back to the original spawnCoords.
    do
        local spawns
        if team and type(team) == 'number' and team > 0 and currentMap then
            if team == 1 then
                spawns = currentMap.redTeamSpawns
            else
                spawns = currentMap.blueTeamSpawns
            end
        end
        if spawns and #spawns > 0 then
            local idx = math.random(#spawns)
            local newSpawn = spawns[idx]
            spawnCoords = newSpawn
        end
    end
    NetworkResurrectLocalPlayer(spawnCoords.x, spawnCoords.y, spawnCoords.z, 0.0, true, false)
    ClearPedTasksImmediately(ped)
    -- Allow a brief moment for the resurrection to take effect, then
    -- fully restore the player's health and clear any bleedout state. We
    -- set health to the ped's maximum and also trigger the hospital
    -- revive event used by qb‑ambulancejob to reset death state.
    Citizen.Wait(100)
    local maxHealth = GetEntityMaxHealth(ped)
    SetEntityHealth(ped, maxHealth)
    -- Trigger the standard revive event provided by qb‑ambulancejob if
    -- available. This ensures any death flags are cleared so the player
    -- is no longer in last stand or bleedout. If the event doesn't exist
    -- on your server, it will simply do nothing.
    TriggerEvent('hospital:client:Revive')
    -- Additionally trigger qbx_medical's playerRevived event if present. In
    -- the qbx framework, this event handles resetting the player's death
    -- state and restoring their health. If the event does not exist it
    -- will be ignored.
    TriggerEvent('qbx_medical:client:playerRevived')
    -- As a fallback, explicitly reset death and laststand status on the
    -- server. These events are provided by qb‑ambulancejob and will
    -- ensure the server clears any dead/laststand flags if the
    -- client‑side revive event does not. If these events are not
    -- available on your server they will be ignored.
    TriggerServerEvent('hospital:server:SetDeathStatus', false)
    TriggerServerEvent('hospital:server:SetLaststandStatus', false)

    -- Reapply team outfit after respawn
    if team then
        applyTeamOutfit(team)
    end

    RemoveAllPedWeapons(ped, true)
    -- Give paintball weapon again. Before equipping the weapon we
    -- temporarily enable weapon usage for this player via
    -- LocalPlayer.state.canUseWeapons. Without this the ox_inventory
    -- restrictions may prevent the weapon from being given. After
    -- giving the weapon we leave this state set to true for the
    -- duration of the match. When the match ends the state will be
    -- reset in qb‑paintball:endGame.
    if currentWeapon then
        print(string.format("🔫 Respawn: currentWeapon data: %s", json.encode(currentWeapon)))
        local weaponHash = toWeaponHash(currentWeapon.hash)
        local ammoAmount = currentWeapon.ammo or 2000 -- Ensure we always have ammo
        print(string.format("🔫 Respawn: hash: %s, ammo: %d", weaponHash, ammoAmount))

        -- Simple and reliable weapon giving
        print(string.format("🔫 Respawn: Attempting to give weapon: %s", currentWeapon.hash))

        -- Set weapon state
        LocalPlayer.state.canUseWeapons = true
        exports.ox_inventory:weaponWheel(true)
        Citizen.Wait(100)

        -- Remove all weapons first
        RemoveAllPedWeapons(ped, true)
        Citizen.Wait(100)

        -- Give weapon - simple approach
        GiveWeaponToPed(ped, weaponHash, ammoAmount, false, true)
        SetCurrentPedWeapon(ped, weaponHash, true)

        -- Check if it worked
        Citizen.Wait(200)
        if HasPedGotWeapon(ped, weaponHash, false) then
            local actualAmmo = GetAmmoInPedWeapon(ped, weaponHash)
            print(string.format("✅ Respawn: Weapon given successfully with %d ammo", actualAmmo))
        else
            print("❌ Respawn: Initial weapon give failed, retrying...")
            -- One retry with different approach
            Citizen.Wait(500)
            LocalPlayer.state.canUseWeapons = true
            exports.ox_inventory:weaponWheel(true)
            GiveWeaponToPed(ped, weaponHash, ammoAmount, false, true)
            SetCurrentPedWeapon(ped, weaponHash, true)

            Citizen.Wait(200)
            if HasPedGotWeapon(ped, weaponHash, false) then
                print("✅ Respawn: Weapon given on retry")
            else
                print("❌ Respawn: Failed to give weapon after retry")
            end
        end

        -- Simple monitoring to catch weapon removal
        Citizen.CreateThread(function()
            Citizen.Wait(2000) -- Wait 2 seconds before starting monitoring

            for i = 1, 10 do -- Monitor for 10 seconds
                Citizen.Wait(1000)

                if inGame and not HasPedGotWeapon(ped, weaponHash, false) then
                    print(string.format("🔄 Respawn: Weapon missing after %d seconds, restoring...", i + 2))
                    LocalPlayer.state.canUseWeapons = true
                    exports.ox_inventory:weaponWheel(true)
                    GiveWeaponToPed(ped, weaponHash, ammoAmount, false, true)
                    SetCurrentPedWeapon(ped, weaponHash, true)
                end
            end

            print("🔫 Respawn monitoring completed")
        end)
    else
        print("❌ Respawn: No currentWeapon stored")
    end
    DoScreenFadeIn(300)
end

-- Opens the paintball lobby menu by focusing the NUI and sending
-- relevant state. The NUI uses messages to update its internal state.
local function openLobbyMenu(host, lobbySettings, currentScoreboard)
    -- Check if weapons are loaded
    if not weaponsLoaded then
        QBCore.Functions.Notify('Loading weapons list...', 'primary', 2000)

        -- Wait for weapons to load with timeout
        local attempts = 0
        while not weaponsLoaded and attempts < 50 do -- 5 second timeout
            Wait(100)
            attempts = attempts + 1
        end

        if not weaponsLoaded then
            QBCore.Functions.Notify('Failed to load weapons, using defaults', 'error')
            availableWeapons = Config.Weapons
            weaponsLoaded = true
        end
    end

    SetNuiFocus(true, true)
    -- Send available weapons to the NUI so hosts can pick which gun
    -- will be used for the match. We send the weapons list (either from
    -- server or config fallback), which includes label, hash and ammo.
    SendNUIMessage({
        action = 'openMenu',
        isHost = host,
        -- Use the provided lobbySettings if available; otherwise fall back
        -- to our last known lobby settings. This allows the menu to
        -- repopulate with the current lobby details when reopening.
        lobby = lobbySettings or lastLobbySettings or nil,
        scoreboard = currentScoreboard or nil,
        team = team,
        weapons = availableWeapons or Config.Weapons,
        maps = Config.Maps
    })
    inLobby = true
end



-- Closes the lobby menu. The scoreboard overlay remains if we are
-- in‑game.
local function closeLobbyMenu()
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'closeMenu' })
end

-- NUI callback: request to create a lobby. We pass kill/time limits
-- back to the server. The callback receives a table containing
-- killLimit and timeLimit.
RegisterNUICallback('createLobby', function(data, cb)
    TriggerServerEvent('Docs-paintball:createLobby', {
        killLimit = data.killLimit,
        timeLimit = data.timeLimit,
        weaponIndex = data.weaponIndex,
        mapIndex = data.mapIndex
    })
    cb({})
end)

-- NUI callback: request to join an existing lobby.
RegisterNUICallback('joinLobby', function(data, cb)
    TriggerServerEvent('Docs-paintball:joinLobby')
    cb({})
end)

-- NUI callback: request to leave the lobby. If we are host this
-- disbands the lobby; otherwise we simply leave.
RegisterNUICallback('leaveLobby', function(data, cb)
    TriggerServerEvent('Docs-paintball:leaveLobby')
    cb({})
end)

-- NUI callback: host requests to start the match.
RegisterNUICallback('startGame', function(data, cb)
    print("🎮 Start game button clicked - sending to server")
    TriggerServerEvent('Docs-paintball:startGame')
    cb({})
end)

-- NUI callback: host updates lobby settings (kill limit, time limit, weapon index).
-- This event is used to modify an existing lobby's configuration without
-- recreating it. Only the host can call this.
RegisterNUICallback('updateLobby', function(data, cb)
    TriggerServerEvent('Docs-paintball:updateLobby', {
        killLimit = data.killLimit,
        timeLimit = data.timeLimit,
        weaponIndex = data.weaponIndex,
        mapIndex = data.mapIndex
    })
    cb({})
end)

-- NUI callback: close menu (e.g. click close button). This does not
-- remove the player from the lobby.
RegisterNUICallback('closeMenu', function(data, cb)
    closeLobbyMenu()
    cb({})
end)

-- Server event: close menu (used when server needs to close the menu)
RegisterNetEvent('Docs-paintball:closeMenu', function()
    closeLobbyMenu()
end)

-- NUI callback: show detailed scoreboard
RegisterNUICallback('showScoreboard', function(data, cb)
    print("📊 Scoreboard button clicked")
    -- Request current scoreboard from server
    TriggerServerEvent('Docs-paintball:requestScoreboard')
    cb({})
end)

-- NUI callback: show all-time stats
RegisterNUICallback('showAllTimeStats', function(data, cb)
    print("🏆 All-time stats button clicked")
    -- Request all-time leaderboard from server
    TriggerServerEvent('Docs-paintball:requestAllTimeStats')
    cb({})
end)

-- NUI callback: show lobby members
RegisterNUICallback('showLobbyMembers', function(data, cb)
    print("👥 Lobby members button clicked")
    -- Request lobby members from server
    TriggerServerEvent('Docs-paintball:requestLobbyMembers')
    cb({})
end)

-- NUI callback: setTeam
-- Allows the player to request a change to their team before the match
-- has begun. The `data.team` value should be 1 or 2. The server
-- validates the request, updates the player's team assignment if
-- possible and broadcasts a lobby refresh. There is no response
-- payload for this callback.
RegisterNUICallback('setTeam', function(data, cb)
    if data and data.team then
        TriggerServerEvent('Docs-paintball:setTeam', data.team)
    end
    cb({})
end)

-- Receive lobby creation response. If success is false a reason may be
-- provided. On success we mark the local player as host and open the
-- menu.
RegisterNetEvent('Docs-paintball:lobbyCreated', function(success, msg)
    if success then
        isHost = true
        -- Save initial lobby settings so we can reopen the menu later
        lastLobbySettings = Config.GameSettings
        openLobbyMenu(true, Config.GameSettings, scoreboard)
    else
        QBCore.Functions.Notify(msg or 'Unable to create lobby.', 'error')
    end
end)

-- Receive join response. If success is false show an error; otherwise
-- record team assignment and open the menu if not already open.
RegisterNetEvent('Docs-paintball:joinedLobby', function(success, t)
    if not success then
        QBCore.Functions.Notify(t or 'Unable to join lobby.', 'error')
        return
    end
    team = t
    isHost = false
    -- Save initial lobby settings on join
    lastLobbySettings = Config.GameSettings
    openLobbyMenu(false, Config.GameSettings, scoreboard)
end)

-- Refresh lobby information. Contains host id, lobby settings and
-- scoreboard for display in the lobby menu. We update our local
-- scoreboard but do not change any state flags.
RegisterNetEvent('Docs-paintball:refreshLobby', function(hostId, settings, score)
    scoreboard = score or scoreboard
    -- Update our cached lobby settings whenever the server tells us about
    -- changes. This ensures we can reopen the menu with up‑to‑date values.
    lastLobbySettings = settings

    -- Update our local team assignment from the scoreboard data
    if scoreboard and scoreboard.individual then
        local myServerId = GetPlayerServerId(PlayerId())
        for _, player in ipairs(scoreboard.individual) do
            if player.id == myServerId then
                team = player.team
                break
            end
        end
    end

    SendNUIMessage({
        action = 'refreshLobby',
        host = hostId,
        lobby = settings,
        scoreboard = scoreboard,
        team = team
    })
end)

-- Notifies us that the lobby has been closed (e.g. host left). We
-- close the menu and reset flags.
RegisterNetEvent('Docs-paintball:lobbyClosed', function()
    if inLobby then
        QBCore.Functions.Notify('Paintball lobby closed.', 'error')
        closeLobbyMenu()
    end
    isHost = false
    team = 0
    inLobby = false
    -- Clear cached lobby settings since the lobby no longer exists
    lastLobbySettings = nil
    scoreboard = { teamKills = { [1] = 0, [2] = 0 }, individual = {} }
    -- Ensure inventory access is restored
    LocalPlayer.state.canUseWeapons = nil
    exports.ox_inventory:weaponWheel(false)
end)

-- Notifies us that we have left the lobby (not host). Resets state.
RegisterNetEvent('Docs-paintball:lobbyLeft', function()
    QBCore.Functions.Notify('You left the paintball lobby.', 'primary')
    closeLobbyMenu()
    -- Reset local flags and cached settings when leaving the lobby
    isHost = false
    inLobby = false
    team = 0
    lastLobbySettings = nil
    scoreboard = { teamKills = { [1] = 0, [2] = 0 }, individual = {} }
    -- Ensure inventory access is restored
    LocalPlayer.state.canUseWeapons = nil
    exports.ox_inventory:weaponWheel(false)
end)

-- Handle team switch result. Provides feedback when team switching succeeds or fails.
RegisterNetEvent('Docs-paintball:joinTeamResult', function(success, message)
    if success then
        QBCore.Functions.Notify('Team switched successfully!', 'success')
    else
        QBCore.Functions.Notify(message or 'Failed to switch teams.', 'error')
    end
end)

-- Handle police alert disabling/enabling during matches
RegisterNetEvent('Docs-paintball:disablePoliceAlerts', function(disable)
    if not Config.DisablePoliceAlerts.Enabled then return end

    local playerId = PlayerId()
    local ped = PlayerPedId()

    if disable then
        -- Disable police alerts during match
        if Config.DisablePoliceAlerts.DisableDispatch then
            -- Disable ps-dispatch alerts by setting player state
            LocalPlayer.state.disableDispatch = true
        end

        if Config.DisablePoliceAlerts.DisableGunshots then
            -- Disable gunshot detection
            LocalPlayer.state.disableGunshots = true
        end

        if Config.DisablePoliceAlerts.DisableDeathAlerts then
            -- Disable death/injury alerts
            LocalPlayer.state.disableDeathAlerts = true
        end

        if Config.DisablePoliceAlerts.DisableMDTAlerts then
            -- Disable MDT alerts
            LocalPlayer.state.disableMDTAlerts = true
        end

        if Config.DisablePoliceAlerts.DisableOfficerDown then
            -- Disable officer down alerts
            LocalPlayer.state.disableOfficerDown = true
            LocalPlayer.state.isInPaintball = true
        end

        if Config.DisablePoliceAlerts.DisableEMSAlerts then
            -- Disable EMS/ambulance alerts
            LocalPlayer.state.disableEMSAlerts = true
        end

        if Config.DisablePoliceAlerts.DisableAllEmergencyAlerts then
            -- Disable all emergency alerts
            LocalPlayer.state.disableAllEmergencyAlerts = true
            LocalPlayer.state.paintballMatch = true
        end

        -- Set player as invincible to prevent actual death/injury
        SetEntityInvincible(ped, true)

    else
        -- Re-enable police alerts after match
        if Config.DisablePoliceAlerts.DisableDispatch then
            -- Re-enable ps-dispatch alerts by clearing player state
            LocalPlayer.state.disableDispatch = false
        end

        if Config.DisablePoliceAlerts.DisableGunshots then
            -- Re-enable gunshot detection
            LocalPlayer.state.disableGunshots = false
        end

        if Config.DisablePoliceAlerts.DisableDeathAlerts then
            -- Re-enable death/injury alerts
            LocalPlayer.state.disableDeathAlerts = false
        end

        if Config.DisablePoliceAlerts.DisableMDTAlerts then
            -- Re-enable MDT alerts
            LocalPlayer.state.disableMDTAlerts = false
        end

        if Config.DisablePoliceAlerts.DisableOfficerDown then
            -- Re-enable officer down alerts
            LocalPlayer.state.disableOfficerDown = false
            LocalPlayer.state.isInPaintball = false
        end

        if Config.DisablePoliceAlerts.DisableEMSAlerts then
            -- Re-enable EMS/ambulance alerts
            LocalPlayer.state.disableEMSAlerts = false
        end

        if Config.DisablePoliceAlerts.DisableAllEmergencyAlerts then
            -- Re-enable all emergency alerts
            LocalPlayer.state.disableAllEmergencyAlerts = false
            LocalPlayer.state.paintballMatch = false
        end

        -- Remove invincibility
        SetEntityInvincible(ped, false)
    end
end)

-- Block ps-dispatch calls during paintball matches
if Config.DisablePoliceAlerts and Config.DisablePoliceAlerts.Enabled then
    -- Block the specific ps-dispatch officer down event
    AddEventHandler('ps-dispatch:client:officerdown', function()
        if LocalPlayer.state.disableOfficerDown or LocalPlayer.state.paintballMatch then
            CancelEvent()
        end
    end)

    -- Block other common ps-dispatch events
    AddEventHandler('ps-dispatch:client:notify', function(data)
        if LocalPlayer.state.disableDispatch or LocalPlayer.state.paintballMatch then
            CancelEvent()
        end
    end)

    -- Block gunshot alerts
    AddEventHandler('ps-dispatch:client:gsrPositive', function()
        if LocalPlayer.state.disableGunshots or LocalPlayer.state.paintballMatch then
            CancelEvent()
        end
    end)

    -- Block EMS alerts
    AddEventHandler('ps-dispatch:client:emsDown', function()
        if LocalPlayer.state.disableEMSAlerts or LocalPlayer.state.paintballMatch then
            CancelEvent()
        end
    end)


end

-- Start game event from the server. Receives a table with spawn
-- coordinates, team and match rules. We save our current state,
-- teleport to spawn and equip the paintball weapon. A short delay
-- allows players to load into the arena before the match begins.
RegisterNetEvent('Docs-paintball:startGame', function(data)
    if not data or not data.spawn then return end
    -- Close the lobby menu automatically if open
    if inLobby then
        closeLobbyMenu()
    end
    inGame = true
    inLobby = false
    team = data.team
    spawnCoords = data.spawn
    killLimit = data.killLimit or Config.GameSettings.killLimit
    timeLimit = data.timeLimit or Config.GameSettings.timeLimit
    currentMap = data.map or Config.Maps[1]
    scoreboard = { teamKills = { [1] = 0, [2] = 0 }, individual = {} }
    remainingTime = timeLimit
    print(string.format("🗺️ Playing on map: %s", currentMap.name))
    -- Save and strip weapons
    savePlayerState()
    local ped = PlayerPedId()
    RemoveAllPedWeapons(ped, true)
    -- Teleport to spawn
    DoScreenFadeOut(500)
    while not IsScreenFadedOut() do Citizen.Wait(50) end
    SetEntityCoordsNoOffset(ped, spawnCoords.x, spawnCoords.y, spawnCoords.z, false, false, false)
    SetEntityHeading(ped, 0.0)

    -- Apply team outfit and radio
    applyTeamOutfit(team)
    setTeamRadio(team)

    -- Wait a bit to make sure other players are spawned before we start
    Citizen.Wait(1000)
    -- Give paintball weapon. We temporarily enable weapon usage via
    -- LocalPlayer.state.canUseWeapons and enable the weapon wheel so
    -- ox_inventory does not block the weapon. Store the selected
    -- weapon in currentWeapon so we can re‑equip it on respawn.
    if data.weapon then
        print(string.format("🔫 Received weapon data: %s", json.encode(data.weapon)))
        local weaponHash = toWeaponHash(data.weapon.hash)
        local ammoAmount = data.weapon.ammo or 2000 -- Default to 2000 if no ammo specified
        print(string.format("🔫 Converted hash: %s, ammo: %d", weaponHash, ammoAmount))

        currentWeapon = {
            hash = data.weapon.hash, -- Store original hash string, not converted
            ammo = ammoAmount
        }

        -- Robust weapon giving with persistence monitoring
        local weaponGiven = false
        local attempts = 0
        local maxAttempts = 5

        while attempts < maxAttempts and not weaponGiven do
            attempts = attempts + 1

            -- Ensure weapon state is set
            LocalPlayer.state.canUseWeapons = true
            exports.ox_inventory:weaponWheel(true)
            Citizen.Wait(200)

            GiveWeaponToPed(ped, weaponHash, ammoAmount, false, true)
            SetCurrentPedWeapon(ped, weaponHash, true)
            print(string.format("🔫 Gave weapon %s with %d ammo (attempt %d)", weaponHash, ammoAmount, attempts))

            Citizen.Wait(500)
            if HasPedGotWeapon(ped, weaponHash, false) then
                local ammoCount = GetAmmoInPedWeapon(ped, weaponHash)
                print(string.format("✅ Weapon successfully given with %d ammo", ammoCount))

                -- Persistence check - wait and verify weapon stays
                Citizen.Wait(2000)
                if HasPedGotWeapon(ped, weaponHash, false) then
                    local ammoCount2 = GetAmmoInPedWeapon(ped, weaponHash)
                    print(string.format("✅ Weapon persisted after 2s with %d ammo", ammoCount2))
                    weaponGiven = true
                else
                    print("❌ Weapon was removed after 2s, retrying...")
                end
            else
                print(string.format("❌ Failed to give weapon (attempt %d/%d)", attempts, maxAttempts))
                if attempts < maxAttempts then
                    Citizen.Wait(1000)
                end
            end
        end

        -- Start continuous monitoring to prevent weapon loss
        if weaponGiven then
            Citizen.CreateThread(function()
                local checkCount = 0
                while checkCount < 30 and inGame do -- Monitor for 30 seconds after spawn
                    Citizen.Wait(1000)
                    checkCount = checkCount + 1

                    if not HasPedGotWeapon(ped, weaponHash, false) then
                        print(string.format("🔄 Initial: Weapon lost after %d seconds, re-giving...", checkCount))
                        LocalPlayer.state.canUseWeapons = true
                        exports.ox_inventory:weaponWheel(true)
                        GiveWeaponToPed(ped, weaponHash, ammoAmount, false, true)
                        SetCurrentPedWeapon(ped, weaponHash, true)
                    end
                end
                print("🔫 Initial weapon monitoring completed")
            end)
        end
    else
        print("❌ No weapon data received")
        currentWeapon = nil
    end
    DoScreenFadeIn(500)
    -- Notify
    QBCore.Functions.Notify('Match starting... Get Ready!', 'primary')
    -- Show scoreboard overlay
    local nuiData = {
        action = 'showScoreboard',
        scoreboard = {
            teamKills = {
                red = (scoreboard and scoreboard.teamKills and scoreboard.teamKills[1]) or 0,
                blue = (scoreboard and scoreboard.teamKills and scoreboard.teamKills[2]) or 0
            },
            individual = (scoreboard and scoreboard.individual) or {}
        },
        timer = remainingTime
    }
    SendNUIMessage(nuiData)
end)

-- Update scoreboard event. Stores the new scoreboard and updates the
-- overlay. This event is sent frequently by the server when kills
-- occur.
RegisterNetEvent('Docs-paintball:updateScoreboard', function(score)
    scoreboard = score or scoreboard


    -- Ensure proper structure for NUI by explicitly creating the object with string keys
    local nuiData = {
        action = 'updateScoreboard',
        scoreboard = {
            teamKills = {
                red = (scoreboard and scoreboard.teamKills and scoreboard.teamKills.red) or 0,
                blue = (scoreboard and scoreboard.teamKills and scoreboard.teamKills.blue) or 0
            },
            individual = (scoreboard and scoreboard.individual) or {}
        }
    }



    SendNUIMessage(nuiData)
end)

-- Update remaining timer. Called by the server each second if a time
-- limit is set.
RegisterNetEvent('Docs-paintball:updateTimer', function(secondsRemaining)
    remainingTime = secondsRemaining
    SendNUIMessage({ action = 'updateTimer', timer = secondsRemaining})
end)

-- End game event. The match is over. We announce the winning team,
-- remove scoreboard overlay and restore player weapon/state. Players
-- remain at the arena until the host starts another round or they
-- choose to leave.
RegisterNetEvent('Docs-paintball:endGame', function(winningTeam, finalScore)
    inGame = false
    SendNUIMessage({ action = 'hideScoreboard' })
    scoreboard = finalScore or scoreboard
    -- Determine message
    local msg
    if winningTeam == 0 then
        msg = 'The match ended in a tie!'
    elseif winningTeam == team then
        msg = 'Your team won the match!'
    else
        msg = 'Your team lost the match.'
    end
    QBCore.Functions.Notify(msg, 'primary')
    -- Reset weapon and inventory state first
    LocalPlayer.state.canUseWeapons = false
    exports.ox_inventory:weaponWheel(false)

    -- Teleport the player back to the lobby marker after a short delay
    Citizen.CreateThread(function()
        Citizen.Wait(2000)
        local ped = PlayerPedId()
        local pos = Config.JoinZone.coords
        DoScreenFadeOut(500)
        while not IsScreenFadedOut() do Citizen.Wait(50) end

        -- FIRST: Ensure player is properly revived and healed
        ReviveInjuredPed(ped)
        ClearPedBloodDamage(ped)
        SetEntityHealth(ped, 200)
        SetPedArmour(ped, 0)

        -- Clear any death/injury states
        TriggerEvent('hospital:client:Revive')
        TriggerEvent('qbx_medical:client:playerRevived')
        TriggerServerEvent('hospital:server:SetDeathStatus', false)
        TriggerServerEvent('hospital:server:SetLaststandStatus', false)

        -- Wait a moment for revival to take effect
        Citizen.Wait(500)

        -- SECOND: Restore outfit and weapon after player is alive
        restorePlayerWeapon()
        print("🎒 Player state fully restored")

        -- Teleport to the lobby/join zone
        SetEntityCoordsNoOffset(ped, pos.x, pos.y, pos.z, false, false, false)
        SetEntityHeading(ped, 0.0)

        -- THIRD: Ensure inventory is properly re-enabled after everything
        Citizen.Wait(500)
        LocalPlayer.state.canUseWeapons = nil

        print("🏁 Player revived and teleported back to lobby")
        TriggerServerEvent('hospital:server:SetLaststandStatus', false)
        TriggerEvent('qbx_medical:client:playerRevived') -- optional again here
        -- ^ Fix for player dead after match ends
        if IsEntityDead(ped) or GetEntityHealth(ped) <= 0 then
            -- Resurrect at the join zone
            NetworkResurrectLocalPlayer(pos.x, pos.y, pos.z, 0.0, true, false)
            ClearPedTasksImmediately(ped)
            Citizen.Wait(100)
            local maxHealth = GetEntityMaxHealth(ped)
            SetEntityHealth(ped, maxHealth)
            -- Trigger revive events for both qb-ambulancejob and qbx_medical
            TriggerEvent('hospital:client:Revive')
            TriggerEvent('qbx_medical:client:playerRevived')
            TriggerServerEvent('hospital:server:SetDeathStatus', false)
            TriggerServerEvent('hospital:server:SetLaststandStatus', false)
        end
        DoScreenFadeIn(500)
        -- Reset spawnCoords to nil so that the next respawn cycle does
        -- not inadvertently teleport the player back to their team
        -- spawn after the game has ended.
        spawnCoords = nil
    end)
end)

-- Thread: monitors the player's proximity to the lobby marker. When
-- within range it draws a marker and 3D text prompt. Pressing E
-- opens the lobby menu. A cooldown prevents spamming.
-- If NPC lobby is disabled, fall back to marker interaction. When
-- Config.NPC.enabled is false we draw a marker and allow players to
-- press E to open the lobby. Otherwise the NPC handles menu
-- interaction via ox_target.
if not (Config.NPC and Config.NPC.enabled) then
    Citizen.CreateThread(function()
        while true do
            local ped = PlayerPedId()
            local coords = GetEntityCoords(ped)
            local dist = #(coords - Config.JoinZone.coords)
            if dist <= Config.JoinZone.radius then
                -- Draw marker
                DrawMarker(Config.JoinZone.markerType, Config.JoinZone.coords.x, Config.JoinZone.coords.y, Config.JoinZone.coords.z - 1.0,
                           0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0,
                           Config.JoinZone.markerColor.r, Config.JoinZone.markerColor.g, Config.JoinZone.markerColor.b, Config.JoinZone.markerColor.a,
                           false, true, 2, nil, nil, false)
                Draw3DText(Config.JoinZone.coords.x, Config.JoinZone.coords.y, Config.JoinZone.coords.z + 0.1, Config.JoinZone.text, 0.4)
                -- Check for key press
                if IsControlJustPressed(0, 38) then
                    if joinCooldown <= 0 and not inGame then
                        -- Pass through isHost so that if the player is the host
                        -- they see the host controls when reopening the lobby.
                        openLobbyMenu(isHost, nil, scoreboard)
                        joinCooldown = Config.GameSettings.joinCooldown
                    end
                end
            end
            if joinCooldown > 0 then
                joinCooldown = joinCooldown - 0.02
            end
            Citizen.Wait(10)
        end
    end)
end

-- Spawn the lobby NPC and attach an ox_target interaction. When the player
-- interacts with the NPC the lobby menu will open. This is only done if
-- Config.NPC.enabled is true. The NPC is placed at Config.NPC.coords and
-- uses the model specified in Config.NPC.model. After spawning the
-- ped, we freeze it in place and make it invincible so it remains in
-- the lobby area. The ox_target option triggers the
-- `qb-paintball:npcInteract` client event defined above.
if Config.NPC and Config.NPC.enabled then
    Citizen.CreateThread(function()
        local modelHash = Config.NPC.model
        -- Support string model names by converting to hash
        if type(modelHash) == 'string' then
            modelHash = GetHashKey(modelHash)
        end
        RequestModel(modelHash)
        while not HasModelLoaded(modelHash) do
            Citizen.Wait(50)
        end
        local coords = Config.NPC.coords
        -- Create the NPC ped at the specified location and heading
        local ped = CreatePed(4, modelHash, coords.x, coords.y, coords.z, coords.w, false, true)
        SetEntityHeading(ped, coords.w)
        SetEntityInvincible(ped, true)
        -- Enable collision so the NPC properly stands on the ground instead of
        -- hovering. Disabling collision caused the ped to float above the
        -- ground. Keep it enabled while still freezing the ped's position.
        SetEntityCollision(ped, true, true)
        FreezeEntityPosition(ped, true)
        -- Play a clipboard animation to give the NPC some life. We use
        -- WORLD_HUMAN_CLIPBOARD so the NPC holds a clipboard and
        -- writes on it. If the scenario is unavailable the ped will
        -- simply stand. We also prevent the NPC from reacting to
        -- damage or other events by blocking non‑temporary events.
        if not IsPedUsingAnyScenario(ped) then
            TaskStartScenarioInPlace(ped, 'WORLD_HUMAN_CLIPBOARD', 0, true)
        end
        SetBlockingOfNonTemporaryEvents(ped, true)
        SetPedFleeAttributes(ped, 0, false)
        SetPedCombatAttributes(ped, 17, 1)
        -- Attach ox_target interaction to the NPC. Use the native
        -- addLocalEntity function provided by ox_target. Each entry in
        -- the options array defines a single selectable option. We set
        -- the distance property on the option itself to control how
        -- close players must be for the eye to appear. This avoids
        -- relying on the qtarget compatibility exports which may not be
        -- available on some servers.
        exports['ox_target']:addLocalEntity(ped, {
            {
                name = 'paintball_lobby',
                label = 'Paintball Lobby',
                icon = 'fa-solid fa-flag',
                -- Directly open the lobby menu when selected instead of
                -- triggering an intermediate event. Pass through the
                -- current host flag so that hosts see the correct controls
                -- when reopening the lobby. Only allow opening if we are
                -- not currently in a match.
                onSelect = function(data)
                    if not inGame then
                        openLobbyMenu(isHost, nil, scoreboard)
                    end
                end,
                distance = Config.NPC.targetDistance or 2.0
            }
        })
    end)
end
-- Thread: monitors player death during a match and handles respawn and
-- notifying the server. When the player dies we send the killer's
-- server ID if available. After a respawn delay the player is
-- resurrected at their spawn point and given the paintball weapon.
Citizen.CreateThread(function()
    while true do
        if inGame then
            local ped = PlayerPedId()
            if IsEntityDead(ped) and (GetGameTimer() - lastDeathTime > 1000) then
                lastDeathTime = GetGameTimer()
                -- Find the killer ped and map to server ID if possible
                local killer = GetPedSourceOfDeath(ped)
                local killerId = nil
                if killer and killer ~= ped then
                    if IsPedAPlayer(killer) then
                        killerId = GetPlayerServerId(NetworkGetPlayerIndexFromPed(killer))
                    end
                end
                TriggerServerEvent('Docs-paintball:playerDied', killerId)
                -- Wait respawn delay then respawn locally. Only respawn
                -- if the game is still running; if it ended during the
                -- delay (e.g. kill limit reached or time expired),
                -- skip the respawn and rely on the endGame handler to
                -- relocate and revive the player.
                Citizen.Wait(Config.GameSettings.respawnDelay * 1000)
                if inGame then
                    respawnPlayer()
                end
            end
        end
        Citizen.Wait(50)
    end
end)

CreateThread(function()
    local blip = AddBlipForCoord(-243.78, -2029.02, 29.95) -- your location
    SetBlipSprite(blip, 160)         -- Pistol icon
    SetBlipDisplay(blip, 4)          -- Show on main map and minimap
    SetBlipScale(blip, 1.0)          -- Size of the blip
    SetBlipColour(blip, 53)           -- Yellow, you can change this
    SetBlipAsShortRange(blip, true)  -- Only visible when nearby
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("PaintBall") -- Name on the map
    EndTextCommandSetBlipName(blip)
end)

-- Emergency command to reset inventory state if it gets stuck
RegisterCommand('paintball_reset', function()
    if not inGame and not inLobby then
        LocalPlayer.state.canUseWeapons = nil
        exports.ox_inventory:weaponWheel(false)
        QBCore.Functions.Notify('Paintball inventory state reset', 'success')
        print("🔧 Emergency inventory reset performed")
    else
        QBCore.Functions.Notify('Cannot reset while in paintball match/lobby', 'error')
    end
end, false)

-- Emergency command to force outfit restoration (especially for females)
RegisterCommand('paintball_outfit_fix', function()
    if not inGame and not inLobby then
        local ped = PlayerPedId()
        local model = GetEntityModel(ped)
        local isMale = (model == GetHashKey("mp_m_freemode_01"))
        local gender = isMale and "male" or "female"

        print(string.format("🔧 Emergency outfit fix for %s", gender))

        -- Try multiple skin reload methods
        pcall(function()
            TriggerEvent('qb-clothing:client:reloadSkin')
        end)

        Citizen.Wait(500)
        pcall(function()
            TriggerEvent('illenium-appearance:client:reloadSkin')
        end)

        Citizen.Wait(500)
        pcall(function()
            TriggerServerEvent('qb-clothing:loadPlayerSkin')
        end)

        Citizen.Wait(500)
        pcall(function()
            TriggerEvent('fivem-appearance:reloadSkin')
        end)

        QBCore.Functions.Notify('Emergency outfit fix applied', 'success')
        print("✅ Emergency outfit fix completed")
    else
        QBCore.Functions.Notify('Cannot use while in paintball match/lobby', 'error')
    end
end, false)

-- Simplified weapon monitoring during matches
Citizen.CreateThread(function()
    local lastWeaponCheck = 0
    while true do
        Citizen.Wait(500) -- Check every 500ms during matches

        if inGame and currentWeapon then
            local ped = PlayerPedId()
            local weaponHash = toWeaponHash(currentWeapon.hash)

            -- If we should have a weapon but don't, restore it
            if not HasPedGotWeapon(ped, weaponHash, false) then
                local currentTime = GetGameTimer()
                if currentTime - lastWeaponCheck > 1000 then -- Prevent spam
                    lastWeaponCheck = currentTime
                    print("🚨 Weapon missing during match! Restoring...")

                    -- Restore weapon state and give weapon
                    LocalPlayer.state.canUseWeapons = true
                    exports.ox_inventory:weaponWheel(true)
                    GiveWeaponToPed(ped, weaponHash, currentWeapon.ammo or 2000, false, true)
                    SetCurrentPedWeapon(ped, weaponHash, true)
                end
            end
        end
    end
end)

-- Force outfit restore event (backup for players who died as last kill)
RegisterNetEvent('Docs-paintball:forceOutfitRestore', function()
    print("🔄 Force outfit restore triggered")
    local ped = PlayerPedId()

    -- Ensure player is alive first
    if IsEntityDead(ped) then
        ReviveInjuredPed(ped)
        ClearPedBloodDamage(ped)
        SetEntityHealth(ped, 200)
        TriggerEvent('hospital:client:Revive')
        TriggerEvent('qbx_medical:client:playerRevived')
        TriggerServerEvent('hospital:server:SetDeathStatus', false)
        TriggerServerEvent('hospital:server:SetLaststandStatus', false)
        Citizen.Wait(500)
    end

    -- Force outfit restoration with enhanced debugging
    if savedOutfit then
        local model = GetEntityModel(ped)
        local isMale = (model == GetHashKey("mp_m_freemode_01"))
        local gender = isMale and "male" or "female"

        print(string.format("👕 Force restoring original %s outfit", gender))
        print(string.format("🔍 Saved outfit data: %s", json.encode(savedOutfit)))

        -- Apply each component with verification
        SetPedComponentVariation(ped, 8, savedOutfit['tshirt_1'], savedOutfit['tshirt_2'], 0)
        Citizen.Wait(50)
        SetPedComponentVariation(ped, 11, savedOutfit['torso_1'], savedOutfit['torso_2'], 0)
        Citizen.Wait(50)
        SetPedComponentVariation(ped, 3, savedOutfit['arms'], 0, 0)
        Citizen.Wait(50)
        SetPedComponentVariation(ped, 4, savedOutfit['pants_1'], savedOutfit['pants_2'], 0)
        Citizen.Wait(50)
        SetPedComponentVariation(ped, 6, savedOutfit['shoes_1'], savedOutfit['shoes_2'], 0)
        Citizen.Wait(50)
        SetPedComponentVariation(ped, 1, savedOutfit['mask_1'], savedOutfit['mask_2'], 0)
        Citizen.Wait(50)
        SetPedComponentVariation(ped, 7, savedOutfit['chain_1'], savedOutfit['chain_2'], 0)
        Citizen.Wait(50)
        SetPedComponentVariation(ped, 5, savedOutfit['bags_1'], savedOutfit['bags_2'], 0)
        Citizen.Wait(50)
        SetPedComponentVariation(ped, 9, savedOutfit['bproof_1'], savedOutfit['bproof_2'], 0)

        -- Restore props with delays
        Citizen.Wait(100)
        if savedOutfit['helmet_1'] and savedOutfit['helmet_1'] ~= -1 then
            SetPedPropIndex(ped, 0, savedOutfit['helmet_1'], savedOutfit['helmet_2'], true)
        else
            ClearPedProp(ped, 0)
        end

        Citizen.Wait(50)
        if savedOutfit['ears_1'] and savedOutfit['ears_1'] ~= -1 then
            SetPedPropIndex(ped, 2, savedOutfit['ears_1'], savedOutfit['ears_2'], true)
        else
            ClearPedProp(ped, 2)
        end

        -- Multiple skin reload attempts with delays
        Citizen.Wait(500)
        print("🔄 Triggering skin reload systems...")

        -- Try QB-Core clothing system
        pcall(function()
            TriggerEvent('qb-clothing:client:reloadSkin')
        end)

        Citizen.Wait(200)

        -- Try illenium-appearance
        pcall(function()
            TriggerEvent('illenium-appearance:client:reloadSkin')
        end)

        Citizen.Wait(200)

        -- Try fivem-appearance
        pcall(function()
            TriggerEvent('fivem-appearance:reloadSkin')
        end)

        Citizen.Wait(200)

        -- Try additional reload methods
        pcall(function()
            TriggerServerEvent('qb-clothing:loadPlayerSkin')
        end)

        pcall(function()
            TriggerEvent('skinchanger:loadSkin', savedOutfit)
        end)

        -- Clear saved outfit
        savedOutfit = nil
        print("✅ Force outfit restore completed for " .. gender)
    else
        print("❌ No saved outfit to restore")
        -- Still trigger skin reload in case there are issues
        pcall(function()
            TriggerEvent('qb-clothing:client:reloadSkin')
            TriggerEvent('illenium-appearance:client:reloadSkin')
            TriggerEvent('fivem-appearance:reloadSkin')
        end)
    end
end)