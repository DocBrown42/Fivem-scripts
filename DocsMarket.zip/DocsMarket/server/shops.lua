-- DocsMarket Shop System
local QBX = exports.qbx_core
local Database = require('server.database')

-- Access global ActiveMarkets from main.lua
local ActiveMarkets = _G.ActiveMarkets

-- Debug function
local function debugPrint(message)
    if Config.Debug then
        print('^3[DocsMarket Debug]^7 ' .. message)
    end
end

-- Send notification to player
local function sendNotification(source, message, type)
    TriggerClientEvent('ox_lib:notify', source, {
        title = 'Black Market',
        description = message,
        type = type or 'info',
        position = Config.Notifications.position,
        duration = Config.Notifications.duration
    })
end

-- Get player identifier
local function getPlayerIdentifier(source)
    local player = QBX:GetPlayer(source)
    if player then
        return player.PlayerData.citizenid
    end
    return nil
end

-- Get item data from ox_inventory
local function getItemData(itemName)
    local itemData = exports.ox_inventory:Items(itemName)
    if itemData then
        return {
            label = itemData.label or itemName,
            description = itemData.description or 'No description available',
            image = 'nui://ox_inventory/web/images/' .. itemName .. '.png'
        }
    else
        return {
            label = itemName,
            description = 'No description available',
            image = 'nui://ox_inventory/web/images/placeholder.png'
        }
    end
end

-- Get items from stash with prices
local function getShopItems(deskId)
    local market = ActiveMarkets[deskId]
    if not market then return {} end

    -- Get shop item prices from database
    local shopPrices = Database.GetShopItems(deskId)
    local stashItems = exports.ox_inventory:GetInventory(market.stashId)

    local items = {}
    if stashItems and stashItems.items then
        for slot, item in pairs(stashItems.items) do
            if item and item.count > 0 then
                local price = shopPrices[item.name]
                if price then -- Only include items that have prices set
                    local itemData = getItemData(item.name)
                    table.insert(items, {
                        name = item.name,
                        label = itemData.label,
                        count = item.count,
                        price = price,
                        image = itemData.image,
                        description = itemData.description
                    })
                end
            end
        end
    end

    return items
end

-- Get stash items for management
local function getStashItems(deskId)
    local market = ActiveMarkets[deskId]
    if not market then return {} end

    -- Get shop item prices from database
    local shopPrices = Database.GetShopItems(deskId)
    local stashItems = exports.ox_inventory:GetInventory(market.stashId)

    local items = {}
    if stashItems and stashItems.items then
        for slot, item in pairs(stashItems.items) do
            if item and item.count > 0 then
                local price = shopPrices[item.name] or 0
                local itemData = getItemData(item.name)
                table.insert(items, {
                    name = item.name,
                    label = itemData.label,
                    count = item.count,
                    price = price,
                    image = itemData.image,
                    description = itemData.description,
                    inShop = price > 0
                })
            end
        end
    end

    return items
end

-- Events
RegisterNetEvent('docsmarket:browseShop', function(deskId)
    local source = source
    debugPrint('=== BROWSE SHOP EVENT ===')
    debugPrint('Source: ' .. source .. ', DeskId: ' .. deskId)

    local identifier = getPlayerIdentifier(source)
    if not identifier then
        debugPrint('ERROR: Unable to identify player')
        sendNotification(source, 'Unable to identify player', 'error')
        return
    end

    debugPrint('Player identifier: ' .. identifier)
    
    local market = ActiveMarkets[deskId]
    if not market then
        sendNotification(source, 'This desk is not occupied', 'error')
        return
    end
    
    -- Don't allow buying from own shop
    if market.owner == identifier then
        sendNotification(source, 'You cannot buy from your own shop', 'error')
        return
    end
    
    local items = getShopItems(deskId)
    if #items == 0 then
        sendNotification(source, 'This shop has no items for sale', 'info')
        return
    end
    
    local shopData = {
        deskId = deskId,
        shopName = 'Black Market Shop #' .. deskId,
        items = items,
        isOwner = false
    }

    debugPrint('=== SENDING SHOP DATA ===')
    debugPrint('Desk ID: ' .. deskId)
    debugPrint('Number of items: ' .. #items)
    debugPrint('Shop name: ' .. shopData.shopName)
    debugPrint('Full data: ' .. json.encode(shopData))

    TriggerClientEvent('docsmarket:openShopNUI', source, shopData)
    debugPrint('Shop NUI event sent to client')
    debugPrint('Player ' .. identifier .. ' browsing shop at desk ' .. deskId)
end)

RegisterNetEvent('docsmarket:openShopManagement', function(deskId)
    local source = source
    debugPrint('=== SHOP MANAGEMENT EVENT ===')
    debugPrint('Source: ' .. source .. ', DeskId: ' .. deskId)

    local identifier = getPlayerIdentifier(source)
    if not identifier then
        debugPrint('ERROR: Unable to identify player')
        sendNotification(source, 'Unable to identify player', 'error')
        return
    end

    debugPrint('Player identifier: ' .. identifier)
    
    local market = ActiveMarkets[deskId]
    if not market or market.owner ~= identifier then
        sendNotification(source, 'You do not own this desk', 'error')
        return
    end
    
    local items = getStashItems(deskId)
    if #items == 0 then
        sendNotification(source, 'No items in stash to manage', 'info')
        return
    end
    
    local managementData = {
        deskId = deskId,
        shopName = 'Manage Shop #' .. deskId,
        items = items,
        isOwner = true
    }

    debugPrint('=== SENDING MANAGEMENT DATA ===')
    debugPrint('Desk ID: ' .. deskId)
    debugPrint('Number of items: ' .. #items)
    debugPrint('Shop name: ' .. managementData.shopName)
    debugPrint('Full data: ' .. json.encode(managementData))

    TriggerClientEvent('docsmarket:openShopManagementNUI', source, managementData)
    debugPrint('Management NUI event sent to client')
    debugPrint('Player ' .. identifier .. ' managing shop at desk ' .. deskId)
end)

RegisterNetEvent('docsmarket:buyItem', function(deskId, itemName, quantity, price)
    local source = source
    local buyerIdentifier = getPlayerIdentifier(source)
    if not buyerIdentifier then
        sendNotification(source, 'Unable to identify player', 'error')
        return
    end
    
    local market = ActiveMarkets[deskId]
    if not market then
        TriggerClientEvent('docsmarket:purchaseResult', source, false, 'This desk is not occupied')
        return
    end
    
    -- Check if trying to buy from own shop
    if market.owner == buyerIdentifier then
        TriggerClientEvent('docsmarket:purchaseResult', source, false, 'You cannot buy from your own shop')
        return
    end
    
    local totalPrice = price * quantity
    
    -- Check if buyer has enough money
    local buyer = QBX:GetPlayer(source)
    if not buyer then
        TriggerClientEvent('docsmarket:purchaseResult', source, false, 'Player data not found')
        return
    end
    
    local buyerMoney = buyer.PlayerData.money.cash or 0
    if buyerMoney < totalPrice then
        TriggerClientEvent('docsmarket:purchaseResult', source, false, 'You need $' .. totalPrice .. ' to buy this item')
        return
    end
    
    -- Check if item exists in stash and has enough quantity
    local stashItems = exports.ox_inventory:GetInventory(market.stashId)
    if not stashItems or not stashItems.items then
        TriggerClientEvent('docsmarket:purchaseResult', source, false, 'Shop inventory not found')
        return
    end
    
    local availableCount = 0
    for slot, item in pairs(stashItems.items) do
        if item and item.name == itemName then
            availableCount = availableCount + item.count
        end
    end
    
    if availableCount < quantity then
        TriggerClientEvent('docsmarket:purchaseResult', source, false, 'Not enough items in stock')
        return
    end
    
    -- Check if buyer has inventory space
    local canAdd = exports.ox_inventory:CanCarryItem(source, itemName, quantity)
    if not canAdd then
        TriggerClientEvent('docsmarket:purchaseResult', source, false, 'Not enough inventory space')
        return
    end
    
    -- Process the transaction
    -- Remove money from buyer
    buyer.Functions.RemoveMoney('cash', totalPrice, 'black-market-purchase')
    
    -- Remove items from stash
    local removed = exports.ox_inventory:RemoveItem(market.stashId, itemName, quantity)
    if not removed then
        -- Refund money if item removal failed
        buyer.Functions.AddMoney('cash', totalPrice, 'black-market-refund')
        TriggerClientEvent('docsmarket:purchaseResult', source, false, 'Failed to remove items from shop')
        return
    end
    
    -- Add items to buyer
    local added = exports.ox_inventory:AddItem(source, itemName, quantity)
    if not added then
        -- Refund money and return items to stash if adding failed
        buyer.Functions.AddMoney('cash', totalPrice, 'black-market-refund')
        exports.ox_inventory:AddItem(market.stashId, itemName, quantity)
        TriggerClientEvent('docsmarket:purchaseResult', source, false, 'Failed to add items to inventory')
        return
    end
    
    -- Calculate seller payment (minus market fee)
    local fee = math.floor(totalPrice * Config.MarketSettings.marketFee)
    local sellerAmount = totalPrice - fee

    -- Add earnings to database instead of direct payment
    Database.AddEarnings(market.owner, deskId, sellerAmount, 'sale', itemName, quantity, buyerIdentifier)

    -- Log transaction
    Database.LogTransaction(deskId, market.owner, buyerIdentifier, itemName, quantity, price, totalPrice, fee, sellerAmount)

    -- Notify seller if online
    local sellerSource = nil
    for playerId, playerData in pairs(QBX:GetQBPlayers()) do
        if playerData.PlayerData.citizenid == market.owner then
            sellerSource = playerId
            break
        end
    end

    if sellerSource then
        sendNotification(sellerSource, 'Sold ' .. quantity .. 'x ' .. itemName .. ' for $' .. sellerAmount .. ' (fee: $' .. fee .. ') - Visit Recovery NPC to claim earnings', 'success')
    end
    
    -- Send success response with updated shop data
    local newShopData = {
        deskId = deskId,
        shopName = 'Black Market Shop #' .. deskId,
        items = getShopItems(deskId),
        isOwner = false
    }
    
    TriggerClientEvent('docsmarket:purchaseResult', source, true, 'Purchased ' .. quantity .. 'x ' .. itemName .. ' for $' .. totalPrice, newShopData)
    debugPrint('Transaction completed: ' .. buyerIdentifier .. ' bought ' .. quantity .. 'x ' .. itemName .. ' for $' .. totalPrice)
end)

RegisterNetEvent('docsmarket:setItemPrice', function(deskId, itemName, price)
    local source = source
    local identifier = getPlayerIdentifier(source)
    if not identifier then
        sendNotification(source, 'Unable to identify player', 'error')
        return
    end
    
    local market = ActiveMarkets[deskId]
    if not market or market.owner ~= identifier then
        TriggerClientEvent('docsmarket:priceSetResult', source, false, 'You do not own this desk')
        return
    end
    
    -- Validate price
    if price < Config.MarketSettings.minPrice or price > Config.MarketSettings.maxPrice then
        TriggerClientEvent('docsmarket:priceSetResult', source, false, 'Invalid price. Must be between $' .. Config.MarketSettings.minPrice .. ' and $' .. Config.MarketSettings.maxPrice)
        return
    end
    
    -- Check if item is restricted
    for _, restrictedItem in pairs(Config.RestrictedItems) do
        if itemName == restrictedItem then
            TriggerClientEvent('docsmarket:priceSetResult', source, false, 'This item cannot be sold in the black market')
            return
        end
    end
    
    -- Set the price in database
    Database.SetItemPrice(deskId, itemName, price)
    
    -- Send success response with updated management data
    local newManagementData = {
        deskId = deskId,
        shopName = 'Manage Shop #' .. deskId,
        items = getStashItems(deskId),
        isOwner = true
    }
    
    TriggerClientEvent('docsmarket:priceSetResult', source, true, 'Set price for ' .. itemName .. ' to $' .. price, newManagementData)
    debugPrint('Player ' .. identifier .. ' set price for ' .. itemName .. ' to $' .. price .. ' at desk ' .. deskId)
end)

RegisterNetEvent('docsmarket:removeFromShop', function(deskId, itemName)
    local source = source
    local identifier = getPlayerIdentifier(source)
    if not identifier then
        sendNotification(source, 'Unable to identify player', 'error')
        return
    end
    
    local market = ActiveMarkets[deskId]
    if not market or market.owner ~= identifier then
        TriggerClientEvent('docsmarket:priceSetResult', source, false, 'You do not own this desk')
        return
    end
    
    -- Remove the item from shop in database
    Database.RemoveItemPrice(deskId, itemName)
    
    -- Send success response with updated management data
    local newManagementData = {
        deskId = deskId,
        shopName = 'Manage Shop #' .. deskId,
        items = getStashItems(deskId),
        isOwner = true
    }
    
    TriggerClientEvent('docsmarket:priceSetResult', source, true, 'Removed ' .. itemName .. ' from shop', newManagementData)
    debugPrint('Player ' .. identifier .. ' removed ' .. itemName .. ' from shop at desk ' .. deskId)
end)
