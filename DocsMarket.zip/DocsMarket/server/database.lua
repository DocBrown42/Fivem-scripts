-- DocsMarket Database Module
local Database = {}

-- Debug function
local function debugPrint(message)
    if Config.Debug then
        print('^3[DocsMarket DB Debug]^7 ' .. message)
    end
end

-- Initialize database tables
function Database.Init()
    debugPrint('Initializing database tables...')
    
    -- Read and execute SQL file
    local sqlFile = LoadResourceFile(GetCurrentResourceName(), 'database.sql')
    if not sqlFile then
        print('^1[DocsMarket Error]^7 Could not load database.sql file')
        return false
    end
    
    -- Split SQL statements and execute them
    local statements = {}
    for statement in sqlFile:gmatch("([^;]+);") do
        local trimmed = statement:gsub("^%s*(.-)%s*$", "%1") -- Trim whitespace
        if trimmed:match("%S") then -- Only non-empty statements
            statements[#statements + 1] = trimmed
        end
    end

    for i = 1, #statements do
        local statement = statements[i]
        debugPrint('Executing SQL: ' .. statement:sub(1, 50) .. '...')

        local success, result = pcall(function()
            return MySQL.query.await(statement)
        end)

        if not success then
            print('^1[DocsMarket DB Error]^7 Failed to execute statement: ' .. statement:sub(1, 100))
            print('^1[DocsMarket DB Error]^7 Error: ' .. tostring(result))
            return false
        end
    end
    
    debugPrint('Database tables initialized successfully')
    return true
end

-- Rental Management
function Database.CreateRental(deskId, ownerIdentifier, stashId, rentalDuration)
    debugPrint('Creating rental for desk ' .. deskId .. ' owner ' .. ownerIdentifier)
    
    local rentalEnd = os.date('%Y-%m-%d %H:%M:%S', os.time() + rentalDuration)
    
    local result = MySQL.insert.await('INSERT INTO docsmarket_rentals (desk_id, owner_identifier, stash_id, rental_end) VALUES (?, ?, ?, ?)', {
        deskId, ownerIdentifier, stashId, rentalEnd
    })
    
    debugPrint('Rental created with ID: ' .. (result or 'failed'))
    return result
end

function Database.GetActiveRental(deskId)
    local result = MySQL.single.await('SELECT * FROM docsmarket_rentals WHERE desk_id = ? AND is_active = 1 AND rental_end > NOW()', {deskId})
    return result
end

function Database.GetPlayerActiveRentals(ownerIdentifier)
    local result = MySQL.query.await('SELECT * FROM docsmarket_rentals WHERE owner_identifier = ? AND is_active = 1 AND rental_end > NOW()', {ownerIdentifier})
    return result or {}
end

function Database.GetPlayerActiveRentalCount(ownerIdentifier)
    local result = MySQL.single.await('SELECT COUNT(*) as count FROM docsmarket_rentals WHERE owner_identifier = ? AND is_active = 1 AND rental_end > NOW()', {ownerIdentifier})
    return result and tonumber(result.count) or 0
end

function Database.GetPlayerRentals(ownerIdentifier)
    local result = MySQL.query.await('SELECT * FROM docsmarket_rentals WHERE owner_identifier = ? AND is_active = 1 AND rental_end > NOW()', {ownerIdentifier})
    return result or {}
end

function Database.ExpireRental(deskId)
    debugPrint('Expiring rental for desk ' .. deskId)
    
    MySQL.update.await('UPDATE docsmarket_rentals SET is_active = 0 WHERE desk_id = ? AND is_active = 1', {deskId})
    return true
end

function Database.GetExpiredRentals()
    local result = MySQL.query.await('SELECT * FROM docsmarket_rentals WHERE is_active = 1 AND rental_end <= NOW()')
    return result or {}
end

-- Shop Item Prices
function Database.SetItemPrice(deskId, itemName, price)
    debugPrint('Setting price for ' .. itemName .. ' at desk ' .. deskId .. ' to $' .. price)
    
    MySQL.query.await('INSERT INTO docsmarket_shop_items (desk_id, item_name, price) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE price = ?, updated_at = NOW()', {
        deskId, itemName, price, price
    })
    return true
end

function Database.RemoveItemPrice(deskId, itemName)
    debugPrint('Removing price for ' .. itemName .. ' at desk ' .. deskId)
    
    MySQL.query.await('DELETE FROM docsmarket_shop_items WHERE desk_id = ? AND item_name = ?', {deskId, itemName})
    return true
end

function Database.GetShopItems(deskId)
    local result = MySQL.query.await('SELECT item_name, price FROM docsmarket_shop_items WHERE desk_id = ?', {deskId})
    
    local items = {}
    if result then
        for _, row in ipairs(result) do
            items[row.item_name] = row.price
        end
    end
    
    return items
end

function Database.ClearShopItems(deskId)
    debugPrint('Clearing all shop items for desk ' .. deskId)
    
    MySQL.query.await('DELETE FROM docsmarket_shop_items WHERE desk_id = ?', {deskId})
    return true
end

-- Earnings Management
function Database.AddEarnings(ownerIdentifier, deskId, amount, transactionType, itemName, quantity, buyerIdentifier)
    debugPrint('Adding earnings: $' .. amount .. ' for ' .. ownerIdentifier .. ' from desk ' .. deskId)
    
    local result = MySQL.insert.await('INSERT INTO docsmarket_earnings (owner_identifier, desk_id, amount, transaction_type, item_name, quantity, buyer_identifier) VALUES (?, ?, ?, ?, ?, ?, ?)', {
        ownerIdentifier, deskId, amount, transactionType or 'sale', itemName, quantity, buyerIdentifier
    })
    
    return result
end

function Database.GetUnclaimedEarnings(ownerIdentifier)
    local result = MySQL.query.await('SELECT * FROM docsmarket_earnings WHERE owner_identifier = ? AND claimed = 0 ORDER BY created_at DESC', {ownerIdentifier})
    return result or {}
end

function Database.GetTotalUnclaimedEarnings(ownerIdentifier)
    local result = MySQL.single.await('SELECT COALESCE(SUM(amount), 0) as total FROM docsmarket_earnings WHERE owner_identifier = ? AND claimed = 0', {ownerIdentifier})
    return result and tonumber(result.total) or 0
end

function Database.ClaimEarnings(ownerIdentifier, amount)
    debugPrint('Claiming $' .. amount .. ' earnings for ' .. ownerIdentifier)
    
    -- Get the oldest unclaimed earnings up to the amount
    local earnings = MySQL.query.await('SELECT id, amount FROM docsmarket_earnings WHERE owner_identifier = ? AND claimed = 0 ORDER BY created_at ASC', {ownerIdentifier})
    
    if not earnings then return false end
    
    local remainingAmount = amount
    local claimedIds = {}
    
    for _, earning in ipairs(earnings) do
        if remainingAmount <= 0 then break end
        
        if earning.amount <= remainingAmount then
            -- Claim this entire earning
            table.insert(claimedIds, earning.id)
            remainingAmount = remainingAmount - earning.amount
        else
            -- Partial claim - split the earning
            local claimAmount = remainingAmount
            local leftoverAmount = earning.amount - claimAmount
            
            -- Mark original as claimed
            table.insert(claimedIds, earning.id)
            
            -- Create new earning for leftover amount
            MySQL.query.await('INSERT INTO docsmarket_earnings (owner_identifier, desk_id, amount, transaction_type, item_name, quantity, buyer_identifier, created_at) SELECT owner_identifier, desk_id, ?, transaction_type, item_name, quantity, buyer_identifier, created_at FROM docsmarket_earnings WHERE id = ?', {
                leftoverAmount, earning.id
            })
            
            remainingAmount = 0
        end
    end
    
    -- Mark claimed earnings
    if #claimedIds > 0 then
        local placeholders = string.rep('?,', #claimedIds):sub(1, -2)
        MySQL.query.await('UPDATE docsmarket_earnings SET claimed = 1, claimed_at = NOW() WHERE id IN (' .. placeholders .. ')', claimedIds)
    end
    
    return amount - remainingAmount -- Return actual amount claimed
end

-- Recovery Items Management
function Database.AddRecoveryItems(ownerIdentifier, deskId, items, reason)
    debugPrint('Adding recovery items for ' .. ownerIdentifier .. ' from desk ' .. deskId .. ' reason: ' .. reason)
    
    for _, item in ipairs(items) do
        MySQL.insert.await('INSERT INTO docsmarket_recovery (owner_identifier, desk_id, item_name, item_count, item_metadata, recovery_reason) VALUES (?, ?, ?, ?, ?, ?)', {
            ownerIdentifier, deskId, item.name, item.count, json.encode(item.metadata or {}), reason
        })
    end
    
    return true
end

function Database.GetRecoveryItems(ownerIdentifier)
    local result = MySQL.query.await('SELECT * FROM docsmarket_recovery WHERE owner_identifier = ? AND claimed = 0 ORDER BY created_at DESC', {ownerIdentifier})
    
    if result then
        for _, item in ipairs(result) do
            item.item_metadata = json.decode(item.item_metadata or '{}')
        end
    end
    
    return result or {}
end

function Database.ClaimRecoveryItems(ownerIdentifier, itemIds)
    debugPrint('Claiming recovery items for ' .. ownerIdentifier .. ': ' .. json.encode(itemIds))
    
    if #itemIds == 0 then return false end
    
    local placeholders = string.rep('?,', #itemIds):sub(1, -2)
    local params = {}
    for _, id in ipairs(itemIds) do
        table.insert(params, id)
    end
    table.insert(params, ownerIdentifier)
    
    MySQL.query.await('UPDATE docsmarket_recovery SET claimed = 1, claimed_at = NOW() WHERE id IN (' .. placeholders .. ') AND owner_identifier = ?', params)
    return true
end

-- Transaction Logging
function Database.LogTransaction(deskId, sellerIdentifier, buyerIdentifier, itemName, quantity, pricePerItem, totalAmount, marketFee, sellerEarnings)
    debugPrint('Logging transaction: ' .. itemName .. ' x' .. quantity .. ' for $' .. totalAmount)
    
    MySQL.insert.await('INSERT INTO docsmarket_transactions (desk_id, seller_identifier, buyer_identifier, item_name, quantity, price_per_item, total_amount, market_fee, seller_earnings) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', {
        deskId, sellerIdentifier, buyerIdentifier, itemName, quantity, pricePerItem, totalAmount, marketFee, sellerEarnings
    })
    return true
end

-- Cleanup functions
function Database.CleanupExpiredRentals()
    debugPrint('Cleaning up expired rentals...')
    
    local expiredRentals = Database.GetExpiredRentals()
    
    for _, rental in ipairs(expiredRentals) do
        -- Move stash items to recovery
        local stashItems = exports.ox_inventory:GetInventory(rental.stash_id)
        if stashItems and stashItems.items then
            local recoveryItems = {}
            for _, item in pairs(stashItems.items) do
                if item and item.count > 0 then
                    table.insert(recoveryItems, {
                        name = item.name,
                        count = item.count,
                        metadata = item.metadata
                    })
                end
            end
            
            if #recoveryItems > 0 then
                Database.AddRecoveryItems(rental.owner_identifier, rental.desk_id, recoveryItems, 'rental_expired')
            end
        end
        
        -- Clear the stash
        exports.ox_inventory:ClearInventory(rental.stash_id)
        
        -- Clear shop items
        Database.ClearShopItems(rental.desk_id)
        
        -- Mark rental as expired
        Database.ExpireRental(rental.desk_id)
    end
    
    debugPrint('Cleaned up ' .. #expiredRentals .. ' expired rentals')
    return #expiredRentals
end

return Database
