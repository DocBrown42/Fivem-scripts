-- DocsMarket Recovery NPC System
local QBX = exports.qbx_core
local Database = require('server.database')

-- Debug function
local function debugPrint(message)
    if Config.Debug then
        print('^3[DocsMarket Recovery Debug]^7 ' .. message)
    end
end

-- Send notification to player
local function sendNotification(source, message, type)
    TriggerClientEvent('ox_lib:notify', source, {
        title = 'Recovery NPC',
        description = message,
        type = type or 'info',
        position = Config.Notifications.position,
        duration = Config.Notifications.duration
    })
end

-- Get player identifier
local function getPlayerIdentifier(source)
    local player = QBX:GetPlayer(source)
    if player then
        return player.PlayerData.citizenid
    end
    return nil
end

-- Get recovery data for player
RegisterNetEvent('docsmarket:getRecoveryData', function()
    local source = source
    debugPrint('=== RECOVERY DATA REQUEST ===')
    debugPrint('Source: ' .. source)

    local identifier = getPlayerIdentifier(source)
    if not identifier then
        debugPrint('ERROR: Unable to identify player')
        sendNotification(source, 'Unable to identify player', 'error')
        return
    end

    debugPrint('Getting recovery data for player: ' .. identifier)
    
    -- Get unclaimed earnings
    local earnings = Database.GetUnclaimedEarnings(identifier) or {}
    local totalEarnings = tonumber(Database.GetTotalUnclaimedEarnings(identifier)) or 0

    -- Get recovery items
    local recoveryItems = Database.GetRecoveryItems(identifier) or {}
    
    -- Format earnings data
    local formattedEarnings = {}
    for _, earning in ipairs(earnings) do
        table.insert(formattedEarnings, {
            id = earning.id,
            amount = earning.amount,
            deskId = earning.desk_id,
            transactionType = earning.transaction_type,
            itemName = earning.item_name,
            quantity = earning.quantity,
            buyerIdentifier = earning.buyer_identifier,
            createdAt = earning.created_at
        })
    end
    
    -- Format recovery items data
    local formattedItems = {}
    for _, item in ipairs(recoveryItems) do
        table.insert(formattedItems, {
            id = item.id,
            deskId = item.desk_id,
            itemName = item.item_name,
            itemCount = item.item_count,
            itemMetadata = item.item_metadata,
            recoveryReason = item.recovery_reason,
            createdAt = item.created_at
        })
    end
    
    local recoveryData = {
        earnings = formattedEarnings,
        totalEarnings = totalEarnings,
        items = formattedItems,
        hasData = totalEarnings > 0 or #formattedItems > 0
    }
    
    debugPrint('Sending recovery data - Earnings: $' .. totalEarnings .. ', Items: ' .. #formattedItems)
    TriggerClientEvent('docsmarket:receiveRecoveryData', source, recoveryData)
end)

-- Claim earnings
RegisterNetEvent('docsmarket:claimEarnings', function(amount)
    local source = source
    debugPrint('=== CLAIM EARNINGS REQUEST ===')
    debugPrint('Source: ' .. source .. ', Amount: ' .. tostring(amount))

    local identifier = getPlayerIdentifier(source)
    if not identifier then
        debugPrint('ERROR: Unable to identify player')
        sendNotification(source, 'Unable to identify player', 'error')
        return
    end

    debugPrint('Player ' .. identifier .. ' claiming $' .. amount .. ' in earnings')
    
    -- Validate amount
    if amount <= 0 then
        sendNotification(source, 'Invalid amount', 'error')
        return
    end
    
    local totalAvailable = Database.GetTotalUnclaimedEarnings(identifier)
    if amount > totalAvailable then
        sendNotification(source, 'You only have $' .. totalAvailable .. ' available to claim', 'error')
        return
    end
    
    -- Get player
    local player = QBX:GetPlayer(source)
    if not player then
        sendNotification(source, 'Player data not found', 'error')
        return
    end
    
    -- Claim earnings from database
    local claimedAmount = Database.ClaimEarnings(identifier, amount)
    
    if claimedAmount > 0 then
        -- Add money to player
        player.Functions.AddMoney('cash', claimedAmount, 'black-market-earnings')
        
        sendNotification(source, 'Claimed $' .. claimedAmount .. ' in earnings', 'success')
        debugPrint('Player ' .. identifier .. ' successfully claimed $' .. claimedAmount)
        
        -- Send updated recovery data
        TriggerEvent('docsmarket:getRecoveryData', source)
    else
        sendNotification(source, 'Failed to claim earnings', 'error')
    end
end)

-- Claim recovery items
RegisterNetEvent('docsmarket:claimRecoveryItems', function(itemIds)
    local source = source
    debugPrint('=== CLAIM RECOVERY ITEMS REQUEST ===')
    debugPrint('Source: ' .. source .. ', ItemIds: ' .. json.encode(itemIds))

    local identifier = getPlayerIdentifier(source)
    if not identifier then
        debugPrint('ERROR: Unable to identify player')
        sendNotification(source, 'Unable to identify player', 'error')
        return
    end

    debugPrint('Player ' .. identifier .. ' claiming recovery items: ' .. json.encode(itemIds))
    
    if not itemIds or #itemIds == 0 then
        sendNotification(source, 'No items selected', 'error')
        return
    end
    
    -- Get the recovery items to validate
    local recoveryItems = Database.GetRecoveryItems(identifier)
    local itemsToRecover = {}
    
    for _, itemId in ipairs(itemIds) do
        for _, recoveryItem in ipairs(recoveryItems) do
            if recoveryItem.id == itemId then
                table.insert(itemsToRecover, recoveryItem)
                break
            end
        end
    end
    
    if #itemsToRecover == 0 then
        sendNotification(source, 'No valid items found', 'error')
        return
    end
    
    -- Check inventory space
    local totalWeight = 0
    for _, item in ipairs(itemsToRecover) do
        local itemData = exports.ox_inventory:Items(item.item_name)
        if itemData then
            totalWeight = totalWeight + (itemData.weight * item.item_count)
        end
    end
    
    local playerInventory = exports.ox_inventory:GetInventory(source)
    if playerInventory and (playerInventory.weight + totalWeight) > playerInventory.maxWeight then
        sendNotification(source, 'Not enough inventory space', 'error')
        return
    end
    
    -- Add items to player inventory
    local successfulItems = {}
    for _, item in ipairs(itemsToRecover) do
        local success = exports.ox_inventory:AddItem(source, item.item_name, item.item_count, item.item_metadata)
        if success then
            table.insert(successfulItems, item.id)
        else
            debugPrint('Failed to add item: ' .. item.item_name .. ' x' .. item.item_count)
        end
    end
    
    if #successfulItems > 0 then
        -- Mark items as claimed in database
        Database.ClaimRecoveryItems(identifier, successfulItems)
        
        sendNotification(source, 'Recovered ' .. #successfulItems .. ' item types', 'success')
        debugPrint('Player ' .. identifier .. ' successfully recovered ' .. #successfulItems .. ' item types')
        
        -- Send updated recovery data
        TriggerEvent('docsmarket:getRecoveryData', source)
    else
        sendNotification(source, 'Failed to recover items', 'error')
    end
end)

-- Claim all earnings
RegisterNetEvent('docsmarket:claimAllEarnings', function()
    local source = source
    debugPrint('=== CLAIM ALL EARNINGS REQUEST ===')
    debugPrint('Source: ' .. source)

    local identifier = getPlayerIdentifier(source)
    if not identifier then
        debugPrint('ERROR: Unable to identify player')
        sendNotification(source, 'Unable to identify player', 'error')
        return
    end

    local totalAvailable = Database.GetTotalUnclaimedEarnings(identifier)
    debugPrint('Total available earnings: $' .. totalAvailable)

    if totalAvailable <= 0 then
        debugPrint('No earnings to claim')
        sendNotification(source, 'No earnings to claim', 'info')
        return
    end

    -- Call claim earnings function directly
    debugPrint('Calling claimEarnings directly with amount: ' .. totalAvailable)

    -- Validate amount
    if totalAvailable <= 0 then
        sendNotification(source, 'Invalid amount', 'error')
        return
    end

    -- Get player
    local player = QBX:GetPlayer(source)
    if not player then
        sendNotification(source, 'Player data not found', 'error')
        return
    end

    -- Claim earnings from database
    local claimedAmount = Database.ClaimEarnings(identifier, totalAvailable)

    if claimedAmount > 0 then
        -- Add money to player
        player.Functions.AddMoney('cash', claimedAmount, 'black-market-earnings')

        sendNotification(source, 'Claimed $' .. claimedAmount .. ' in earnings', 'success')
        debugPrint('Player ' .. identifier .. ' successfully claimed $' .. claimedAmount)

        -- Send updated recovery data
        TriggerEvent('docsmarket:getRecoveryData')
    else
        sendNotification(source, 'Failed to claim earnings', 'error')
    end
end)

-- Claim all recovery items
RegisterNetEvent('docsmarket:claimAllRecoveryItems', function()
    local source = source
    debugPrint('=== CLAIM ALL RECOVERY ITEMS REQUEST ===')
    debugPrint('Source: ' .. source)

    local identifier = getPlayerIdentifier(source)
    if not identifier then
        debugPrint('ERROR: Unable to identify player')
        sendNotification(source, 'Unable to identify player', 'error')
        return
    end

    local recoveryItems = Database.GetRecoveryItems(identifier)
    debugPrint('Found ' .. #recoveryItems .. ' recovery items')

    if #recoveryItems == 0 then
        debugPrint('No items to recover')
        sendNotification(source, 'No items to recover', 'info')
        return
    end

    local itemIds = {}
    for _, item in ipairs(recoveryItems) do
        table.insert(itemIds, item.id)
    end

    debugPrint('Processing recovery items: ' .. json.encode(itemIds))

    -- Process recovery items directly
    local itemsToRecover = recoveryItems -- We already have the items

    -- Check inventory space
    local totalWeight = 0
    for _, item in ipairs(itemsToRecover) do
        local itemData = exports.ox_inventory:Items(item.item_name)
        if itemData then
            totalWeight = totalWeight + (itemData.weight * item.item_count)
        end
    end

    local playerInventory = exports.ox_inventory:GetInventory(source)
    if playerInventory and (playerInventory.weight + totalWeight) > playerInventory.maxWeight then
        sendNotification(source, 'Not enough inventory space', 'error')
        return
    end

    -- Add items to player inventory
    local successfulItems = {}
    for _, item in ipairs(itemsToRecover) do
        local success = exports.ox_inventory:AddItem(source, item.item_name, item.item_count, item.item_metadata)
        if success then
            table.insert(successfulItems, item.id)
        else
            debugPrint('Failed to add item: ' .. item.item_name .. ' x' .. item.item_count)
        end
    end

    if #successfulItems > 0 then
        -- Mark items as claimed in database
        Database.ClaimRecoveryItems(identifier, successfulItems)

        sendNotification(source, 'Recovered ' .. #successfulItems .. ' item types', 'success')
        debugPrint('Player ' .. identifier .. ' successfully recovered ' .. #successfulItems .. ' item types')

        -- Send updated recovery data
        TriggerEvent('docsmarket:getRecoveryData')
    else
        sendNotification(source, 'Failed to recover items', 'error')
    end
end)

debugPrint('Recovery NPC system loaded')
