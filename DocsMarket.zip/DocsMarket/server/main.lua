-- DocsMarket Server Main
local QBX = exports.qbx_core

-- Load database module
local Database = require('server.database')

-- Storage for market data (now backed by database)
_G.ActiveMarkets = {} -- [deskId] = {owner, stashId, expiry, playerSource} - Made global for shops.lua

-- Debug function
local function debugPrint(message)
    if Config.Debug then
        print('^3[DocsMarket Debug]^7 ' .. message)
    end
end

-- Get player identifier
local function getPlayerIdentifier(source)
    local player = QBX:GetPlayer(source)
    if player then
        return player.PlayerData.citizenid
    end
    return nil
end

-- Send notification to player
local function sendNotification(source, message, type)
    TriggerClientEvent('ox_lib:notify', source, {
        title = 'Black Market',
        description = message,
        type = type or 'info',
        position = Config.Notifications.position,
        duration = Config.Notifications.duration
    })
end

-- Create market stash
local function createMarketStash(deskId, owner)
    local stashId = 'blackmarket_' .. deskId .. '_' .. owner
    
    -- Register the stash with ox_inventory
    exports.ox_inventory:RegisterStash(stashId, 'Black Market Desk #' .. deskId, Config.MarketSettings.maxItemsPerStash, Config.MarketSettings.maxWeightPerStash, owner)
    
    debugPrint('Created market stash: ' .. stashId .. ' for player: ' .. owner)
    return stashId
end

-- Save items for recovery
local function saveItemsForRecovery(identifier, stashId)
    local stashItems = exports.ox_inventory:GetInventory(stashId)
    if stashItems and stashItems.items then
        local items = {}
        for slot, item in pairs(stashItems.items) do
            if item and item.count > 0 then
                items[item.name] = (items[item.name] or 0) + item.count
            end
        end
        
        if next(items) then
            PlayerRecoveryItems[identifier] = {
                items = items,
                timestamp = os.time()
            }
            debugPrint('Saved ' .. table.count(items) .. ' item types for recovery for player: ' .. identifier)
        end
    end
end

-- Callbacks
lib.callback.register('docsmarket:getDeskStatus', function(source, deskId)
    local identifier = getPlayerIdentifier(source)
    if not identifier then return nil end
    
    local market = ActiveMarkets[deskId]
    local status = {
        occupied = market ~= nil,
        isOwner = market and market.owner == identifier,
        owner = market and market.owner or nil,
        expiry = market and market.expiry or nil
    }
    
    return status
end)

-- Events
RegisterNetEvent('docsmarket:rentDesk', function(deskId, durationIndex)
    local source = source
    local identifier = getPlayerIdentifier(source)
    if not identifier then
        sendNotification(source, 'Unable to identify player', 'error')
        return
    end

    -- Validate duration index
    if not durationIndex or not Config.Operations.rentalOptions[durationIndex] then
        sendNotification(source, 'Invalid rental duration selected', 'error')
        return
    end

    local rentalOption = Config.Operations.rentalOptions[durationIndex]

    -- Check if desk is already occupied
    if ActiveMarkets[deskId] then
        sendNotification(source, 'This desk is already occupied', 'error')
        return
    end

    -- Check player's current shop count
    local currentShopCount = Database.GetPlayerActiveRentalCount(identifier)
    if currentShopCount >= Config.Operations.maxShopsPerPlayer then
        sendNotification(source, 'You can only rent ' .. Config.Operations.maxShopsPerPlayer .. ' shop(s) at a time', 'error')
        return
    end

    -- Check if player has enough money
    local player = QBX:GetPlayer(source)
    if not player then
        sendNotification(source, 'Player data not found', 'error')
        return
    end

    local playerMoney = player.PlayerData.money.cash or 0
    if playerMoney < rentalOption.cost then
        sendNotification(source, 'You need $' .. rentalOption.cost .. ' to rent this desk for ' .. rentalOption.label, 'error')
        return
    end

    -- Remove money
    player.Functions.RemoveMoney('cash', rentalOption.cost, 'black-market-rent')

    -- Create stash
    local stashId = createMarketStash(deskId, identifier)

    -- Store active market data
    ActiveMarkets[deskId] = {
        owner = identifier,
        stashId = stashId,
        expiry = os.time() + rentalOption.duration,
        playerSource = source
    }

    -- Store rental in database
    Database.CreateRental(deskId, identifier, stashId, rentalOption.duration)

    sendNotification(source, 'Market desk #' .. deskId .. ' rented for ' .. rentalOption.label .. '!', 'success')
    TriggerClientEvent('docsmarket:deskRented', source, deskId, rentalOption.duration)

    debugPrint('Player ' .. identifier .. ' rented desk ' .. deskId .. ' for ' .. rentalOption.label)
end)

RegisterNetEvent('docsmarket:releaseDesk', function(deskId)
    local source = source
    local identifier = getPlayerIdentifier(source)
    if not identifier then
        sendNotification(source, 'Unable to identify player', 'error')
        return
    end
    
    local market = ActiveMarkets[deskId]
    if not market or market.owner ~= identifier then
        sendNotification(source, 'You do not own this desk', 'error')
        return
    end
    
    -- Save items for recovery using database
    local stashItems = exports.ox_inventory:GetInventory(market.stashId)
    if stashItems and stashItems.items then
        local recoveryItems = {}
        for _, item in pairs(stashItems.items) do
            if item and item.count > 0 then
                table.insert(recoveryItems, {
                    name = item.name,
                    count = item.count,
                    metadata = item.metadata
                })
            end
        end

        if #recoveryItems > 0 then
            Database.AddRecoveryItems(identifier, deskId, recoveryItems, 'manual')
        end
    end

    -- Clear stash
    exports.ox_inventory:ClearInventory(market.stashId)

    -- Clear shop items from database
    Database.ClearShopItems(deskId)

    -- Expire rental in database
    Database.ExpireRental(deskId)

    -- Remove from active markets
    ActiveMarkets[deskId] = nil

    sendNotification(source, 'Market desk #' .. deskId .. ' released. Items saved for recovery.', 'success')
    TriggerClientEvent('docsmarket:deskReleased', source, deskId)

    debugPrint('Player ' .. identifier .. ' released desk ' .. deskId)
end)

RegisterNetEvent('docsmarket:openStash', function(deskId)
    local source = source
    local identifier = getPlayerIdentifier(source)
    if not identifier then
        sendNotification(source, 'Unable to identify player', 'error')
        return
    end
    
    local market = ActiveMarkets[deskId]
    if not market or market.owner ~= identifier then
        sendNotification(source, 'You do not own this desk', 'error')
        return
    end
    
    exports.ox_inventory:forceOpenInventory(source, 'stash', market.stashId)
    debugPrint('Player ' .. identifier .. ' opened stash for desk ' .. deskId)
end)

RegisterNetEvent('docsmarket:requestRecovery', function()
    local source = source
    local identifier = getPlayerIdentifier(source)
    if not identifier then
        sendNotification(source, 'Unable to identify player', 'error')
        return
    end
    
    local recoveryData = PlayerRecoveryItems[identifier]
    if not recoveryData then
        sendNotification(source, 'No items to recover', 'error')
        return
    end
    
    -- Give items back to player
    local recovered = {}
    for itemName, count in pairs(recoveryData.items) do
        local added = exports.ox_inventory:AddItem(source, itemName, count)
        if added then
            recovered[itemName] = count
        end
    end
    
    if next(recovered) then
        PlayerRecoveryItems[identifier] = nil
        TriggerClientEvent('docsmarket:receiveRecoveryItems', source, recovered)
        sendNotification(source, 'Items recovered successfully!', 'success')
        debugPrint('Player ' .. identifier .. ' recovered items')
    else
        sendNotification(source, 'Failed to recover items - check inventory space', 'error')
    end
end)

-- Cleanup expired markets
CreateThread(function()
    while true do
        Wait(60000) -- Check every minute

        -- Use database cleanup function
        local cleanedCount = Database.CleanupExpiredRentals()

        if cleanedCount > 0 then
            debugPrint('Cleaned up ' .. cleanedCount .. ' expired rentals')

            -- Update ActiveMarkets to match database
            for deskId = 1, #Config.DeskLocations do
                local rental = Database.GetActiveRental(deskId)
                if rental then
                    -- Update existing or add new
                    if not ActiveMarkets[deskId] then
                        ActiveMarkets[deskId] = {
                            owner = rental.owner_identifier,
                            stashId = rental.stash_id,
                            expiry = rental.rental_end,
                            playerSource = nil
                        }
                    end
                else
                    -- Remove expired
                    if ActiveMarkets[deskId] then
                        local market = ActiveMarkets[deskId]

                        -- Notify player if online
                        if market.playerSource then
                            sendNotification(market.playerSource, 'Your market desk rental has expired. Items saved for recovery at the Recovery NPC.', 'info')
                            TriggerClientEvent('docsmarket:deskReleased', market.playerSource, deskId)
                        end

                        ActiveMarkets[deskId] = nil
                    end
                end
            end
        end
    end
end)

-- Initialize on resource start
CreateThread(function()
    Wait(1000) -- Wait for other resources to load

    -- Command to check player's active shops
RegisterCommand('myshops', function(source, args, rawCommand)
    local identifier = getPlayerIdentifier(source)
    if not identifier then
        sendNotification(source, 'Unable to identify player', 'error')
        return
    end

    local activeRentals = Database.GetPlayerActiveRentals(identifier)
    local count = #activeRentals

    if count == 0 then
        sendNotification(source, 'You have no active shop rentals', 'info')
    else
        local message = 'Your Active Shops (' .. count .. '/' .. Config.Operations.maxShopsPerPlayer .. '):'
        for _, rental in ipairs(activeRentals) do
            local timeLeft = rental.rental_end - os.time()
            if timeLeft > 0 then
                local timeStr = formatTime(timeLeft)
                message = message .. '\n• Desk #' .. rental.desk_id .. ' - ' .. timeStr .. ' remaining'
            end
        end

        TriggerClientEvent('chat:addMessage', source, {
            color = {0, 255, 0},
            multiline = true,
            args = {'Black Market', message}
        })
    end
end, false)

-- Helper function for server-side time formatting
local function formatTime(seconds)
    local days = math.floor(seconds / 86400)
    local hours = math.floor((seconds % 86400) / 3600)
    local minutes = math.floor((seconds % 3600) / 60)

    if days > 0 then
        return string.format('%dd %dh', days, hours)
    elseif hours > 0 then
        return string.format('%dh %dm', hours, minutes)
    else
        return string.format('%dm', minutes)
    end
end

debugPrint('DocsMarket server initialization started')

    -- Initialize database
    if not Database.Init() then
        print('^1[DocsMarket Error]^7 Failed to initialize database')
        return
    end

    -- Load existing active rentals from database
    for deskId = 1, #Config.DeskLocations do
        local rental = Database.GetActiveRental(deskId)
        if rental then
            debugPrint('Loading existing rental for desk ' .. deskId .. ' owner: ' .. rental.owner_identifier)

            ActiveMarkets[deskId] = {
                owner = rental.owner_identifier,
                stashId = rental.stash_id,
                expiry = rental.rental_end,
                playerSource = nil -- Will be set when player comes online
            }

            -- Update desk status
            Config.DeskLocations[deskId].occupied = true
            Config.DeskLocations[deskId].owner = rental.owner_identifier
            Config.DeskLocations[deskId].stashId = rental.stash_id
        else
            -- Reset desk status
            Config.DeskLocations[deskId].occupied = false
            Config.DeskLocations[deskId].owner = nil
            Config.DeskLocations[deskId].stashId = nil
        end
    end

    -- Clean up expired rentals
    Database.CleanupExpiredRentals()

    print('^2[DocsMarket]^7 Black Market system initialized with ' .. #Config.DeskLocations .. ' desk locations')
end)

-- Debug commands
if Config.Debug then
    RegisterCommand('bmstatus', function(source)
        local activeCount = 0
        for _ in pairs(ActiveMarkets) do activeCount = activeCount + 1 end
        
        print('^2[DocsMarket Status]^7')
        print('Active Markets: ' .. activeCount)
        for deskId, market in pairs(ActiveMarkets) do
            print('  Desk ' .. deskId .. ': Owner = ' .. market.owner .. ', Expires = ' .. os.date('%H:%M:%S', market.expiry))
        end
        
        local recoveryCount = 0
        for _ in pairs(PlayerRecoveryItems) do recoveryCount = recoveryCount + 1 end
        print('Players with recovery items: ' .. recoveryCount)
    end, false)
    
    RegisterCommand('bmrelease', function(source, args)
        local deskId = tonumber(args[1])
        if deskId and ActiveMarkets[deskId] then
            local market = ActiveMarkets[deskId]
            saveItemsForRecovery(market.owner, market.stashId)
            exports.ox_inventory:ClearInventory(market.stashId)
            ActiveMarkets[deskId] = nil
            print('^2[DocsMarket]^7 Force released desk ' .. deskId)
        else
            print('^1[DocsMarket]^7 Invalid desk ID or desk not occupied')
        end
    end, false)
end
