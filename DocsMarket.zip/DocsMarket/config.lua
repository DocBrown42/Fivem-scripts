Config = {}

-- Framework settings
Config.Framework = 'qbx' -- qbx, esx, qb

-- Market settings
Config.MarketSettings = {
    maxItemsPerStash = 50,
    maxWeightPerStash = 100000, -- in grams
    marketFee = 0.05, -- 5% fee on sales
    maxPrice = 999999, -- maximum price per item
    minPrice = 1, -- minimum price per item
}

-- Desk prop settings
Config.DeskProp = 'prop_office_desk_01' -- The prop model for market desks
Config.DeskSettings = {
    deleteOnRestart = true, -- Delete desk props on server restart
    spawnDistance = 100.0, -- Distance to spawn desks for players
}

-- 10 Black Market Desk Locations (hidden/underground locations)
Config.DeskLocations = {
    {
        id = 1,
        coords = vector3(-61.8, -1218.33, 27.77),
        heading = 267.44,
        occupied = false,
        owner = nil,
        stashId = nil
    },
    {
        id = 2,
        coords = vector3(-56.39, -1228.22, 27.78),
        heading = 45.68,
        occupied = false,
        owner = nil,
        stashId = nil
    },
    {
        id = 3,
        coords = vector3(-66.29, -1227.69, 27.85),
        heading = 241.56,
        occupied = false,
        owner = nil,
        stashId = nil
    },
    {
        id = 4,
        coords = vector3(-60.82, -1232.98, 27.9),
        heading = 52.93,
        occupied = false,
        owner = nil,
        stashId = nil
    },
    {
        id = 5,
        coords = vector3(-71.86, -1234.5, 28.09),
        heading = 233.7,
        occupied = false,
        owner = nil,
        stashId = nil
    },
    {
        id = 6,
        coords = vector3(-56.76, -1210.9, 27.51),
        heading = 131.15,
        occupied = false,
        owner = nil,
        stashId = nil
    },
    {
        id = 7,
        coords = vector3(-64.81, -1210.41, 27.32),
        heading = 318.48,
        occupied = false,
        owner = nil,
        stashId = nil
    },
    {
        id = 8,
        coords = vector3(-62.23, -1204.67, 27.12),
        heading = 124.58,
        occupied = false,
        owner = nil,
        stashId = nil
    },
    {
        id = 9,
        coords = vector3(-70.4, -1205.62, 26.87),
        heading = 318.39,
        occupied = false,
        owner = nil,
        stashId = nil
    },
    {
        id = 10,
        coords = vector3(-67.76, -1199.82, 26.78),
        heading = 135.25,
        occupied = false,
        owner = nil,
        stashId = nil
    }
}

-- NPC Recovery Location (where players can claim items after server restart)
Config.RecoveryNPC = {
    coords = vector3(-49.74, -1224.48, 27.89), -- Downtown underground (near desk 2)
    heading = 350.36,
    model = 'a_m_m_business_01',
    scenario = 'WORLD_HUMAN_CLIPBOARD',
    name = 'Black Market Recovery',
    blip = {
        enabled = false,
        sprite = 500,
        color = 1,
        scale = 0.8,
        name = 'Item Recovery'
    }
}

-- Restricted items (items that cannot be sold in black market)
Config.RestrictedItems = {
    'money', -- Prevent money duplication
    'black_money', -- Framework specific
    'bank', -- Framework specific
    'crypto', -- Framework specific
}

-- Allowed item categories (if empty, all items except restricted are allowed)
Config.AllowedCategories = {
    'weapon', 
    'ammo',   
    'consumable',
    'item',
    'misc',
}

-- Market operation settings
Config.Operations = {
    maxShopsPerPlayer = 1, -- Maximum number of shops each player can rent
    autoCleanup = true, -- Automatically cleanup expired markets
    notifyExpiry = true, -- Notify players when market is about to expire
    expiryWarning = 300, -- Warning time before expiry (5 minutes)
    rentalOptions = {
        {
            label = "1 Hour",
            duration = 3600, -- 1 hour in seconds
            cost = 2500
        },
        {
            label = "6 Hours",
            duration = 21600, -- 6 hours in seconds
            cost = 12000
        },
        {
            label = "12 Hours",
            duration = 43200, -- 12 hours in seconds
            cost = 20000
        },
        {
            label = "24 Hours",
            duration = 86400, -- 24 hours in seconds
            cost = 35000
        }
    }
}

-- Notification settings
Config.Notifications = {
    type = 'ox_lib', -- ox_lib, qb, esx, custom
    position = 'top-right',
    duration = 5000,
}

-- Recovery NPC
Config.RecoveryNPC = {
    location = vector4(-49.740001678467, -1224.4799804688, 27.889999389648, 350.35995483398), -- Black market location
    model = 'a_m_m_business_01',
    scenario = 'WORLD_HUMAN_CLIPBOARD',
    blip = {
        sprite = 280,
        color = 1,
        scale = 0.8,
        label = 'Black Market Recovery'
    }
}

-- Debug settings
Config.Debug = true -- Set to true for debug prints