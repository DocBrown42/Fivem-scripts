-- DocsMarket Database Tables

-- Table for active market rentals
CREATE TABLE IF NOT EXISTS `docsmarket_rentals` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `desk_id` int(11) NOT NULL,
    `owner_identifier` varchar(50) NOT NULL,
    `stash_id` varchar(100) NOT NULL,
    `rental_start` timestamp DEFAULT CURRENT_TIMESTAMP,
    `rental_end` timestamp NOT NULL,
    `is_active` tinyint(1) DEFAULT 1,
    PRIMARY KEY (`id`),
    UNIQUE KEY `desk_id` (`desk_id`),
    KEY `owner_identifier` (`owner_identifier`)
);

-- Table for shop item prices and settings
CREATE TABLE IF NOT EXISTS `docsmarket_shop_items` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `desk_id` int(11) NOT NULL,
    `item_name` varchar(50) NOT NULL,
    `price` int(11) NOT NULL,
    `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
    `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `desk_item` (`desk_id`, `item_name`),
    KEY `desk_id` (`desk_id`)
);

-- Table for unclaimed shop earnings
CREATE TABLE IF NOT EXISTS `docsmarket_earnings` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `owner_identifier` varchar(50) NOT NULL,
    `desk_id` int(11) NOT NULL,
    `amount` int(11) NOT NULL,
    `transaction_type` enum('sale', 'rental_refund') DEFAULT 'sale',
    `item_name` varchar(50) DEFAULT NULL,
    `quantity` int(11) DEFAULT NULL,
    `buyer_identifier` varchar(50) DEFAULT NULL,
    `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
    `claimed` tinyint(1) DEFAULT 0,
    `claimed_at` timestamp NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY `owner_identifier` (`owner_identifier`),
    KEY `claimed` (`claimed`)
);

-- Table for recovery items (when rentals expire or server restarts)
CREATE TABLE IF NOT EXISTS `docsmarket_recovery` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `owner_identifier` varchar(50) NOT NULL,
    `desk_id` int(11) NOT NULL,
    `item_name` varchar(50) NOT NULL,
    `item_count` int(11) NOT NULL,
    `item_metadata` longtext DEFAULT NULL,
    `recovery_reason` enum('rental_expired', 'server_restart', 'manual') DEFAULT 'rental_expired',
    `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
    `claimed` tinyint(1) DEFAULT 0,
    `claimed_at` timestamp NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY `owner_identifier` (`owner_identifier`),
    KEY `claimed` (`claimed`)
);

-- Table for transaction history (optional, for logging)
CREATE TABLE IF NOT EXISTS `docsmarket_transactions` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `desk_id` int(11) NOT NULL,
    `seller_identifier` varchar(50) NOT NULL,
    `buyer_identifier` varchar(50) NOT NULL,
    `item_name` varchar(50) NOT NULL,
    `quantity` int(11) NOT NULL,
    `price_per_item` int(11) NOT NULL,
    `total_amount` int(11) NOT NULL,
    `market_fee` int(11) NOT NULL,
    `seller_earnings` int(11) NOT NULL,
    `transaction_date` timestamp DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `seller_identifier` (`seller_identifier`),
    KEY `buyer_identifier` (`buyer_identifier`),
    KEY `desk_id` (`desk_id`)
);

-- Indexes for better performance
CREATE INDEX IF NOT EXISTS `idx_rentals_active` ON `docsmarket_rentals` (`is_active`, `rental_end`);
CREATE INDEX IF NOT EXISTS `idx_earnings_unclaimed` ON `docsmarket_earnings` (`owner_identifier`, `claimed`);
CREATE INDEX IF NOT EXISTS `idx_recovery_unclaimed` ON `docsmarket_recovery` (`owner_identifier`, `claimed`);
CREATE INDEX IF NOT EXISTS `idx_transactions_date` ON `docsmarket_transactions` (`transaction_date`);
