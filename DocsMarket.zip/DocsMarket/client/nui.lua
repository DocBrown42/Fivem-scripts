-- DocsMarket NUI Handler
local nuiOpen = false
local currentShopData = nil
local currentManagementData = nil

-- Debug function
local function debugPrint(message)
    if Config.Debug then
        print('^3[DocsMarket NUI Debug]^7 ' .. message)
    end
end

-- Notification function
local function showNotification(message, type)
    TriggerEvent('ox_lib:notify', {
        title = 'Black Market',
        description = message,
        type = type or 'info',
        position = Config.Notifications.position,
        duration = Config.Notifications.duration
    })
end

-- Function to open shop NUI
local function openShopNUI(shopData)
    debugPrint('=== OPENING SHOP NUI ===')
    debugPrint('Shop data received: ' .. json.encode(shopData))
    debugPrint('Number of items: ' .. #shopData.items)

    -- Close any existing NUI first
    if nuiOpen then
        debugPrint('Closing existing NUI before opening shop')
        closeShopNUI()
        Wait(200) -- Longer delay to ensure cleanup
    end

    debugPrint('Setting NUI focus...')
    SetNuiFocus(true, true)
    nuiOpen = true
    currentShopData = shopData

    -- Small delay before sending message to prevent immediate close
    Wait(50)

    debugPrint('Sending NUI message...')
    SendNUIMessage({
        action = 'openShop',
        data = shopData
    })

    debugPrint('NUI message sent')
end

-- Function to close shop NUI
local function closeShopNUI()
    debugPrint('=== CLOSING SHOP NUI ===')
    debugPrint('Current nuiOpen state: ' .. tostring(nuiOpen))

    -- Prevent recursive closing
    if not nuiOpen then
        debugPrint('NUI already closed, skipping')
        return
    end

    SetNuiFocus(false, false)
    nuiOpen = false

    SendNUIMessage({
        action = 'closeShop'
    })

    -- Reset NUI state
    currentShopData = nil
    currentManagementData = nil

    debugPrint('NUI closed and state reset')
end

-- Function to open shop management NUI
local function openShopManagementNUI(managementData)
    debugPrint('=== OPENING SHOP MANAGEMENT NUI ===')
    debugPrint('Management data received: ' .. json.encode(managementData))
    debugPrint('Number of items: ' .. #managementData.items)

    -- Close any existing NUI first
    if nuiOpen then
        debugPrint('Closing existing NUI before opening management')
        closeShopNUI()
        Wait(200) -- Longer delay to ensure cleanup
    end

    debugPrint('Setting NUI focus...')
    SetNuiFocus(true, true)
    nuiOpen = true
    currentManagementData = managementData

    -- Small delay before sending message to prevent immediate close
    Wait(50)

    debugPrint('Sending NUI message...')
    SendNUIMessage({
        action = 'openManagement',
        data = managementData
    })

    debugPrint('NUI message sent')
end

-- NUI Callbacks
RegisterNUICallback('closeShop', function(data, cb)
    debugPrint('NUI callback: closeShop received')

    -- Prevent recursive closing
    if not nuiOpen then
        debugPrint('NUI already closed, ignoring callback')
        cb('ok')
        return
    end

    closeShopNUI()
    cb('ok')
end)

RegisterNUICallback('buyItem', function(data, cb)
    debugPrint('Player wants to buy: ' .. data.itemName .. ' x' .. data.quantity)
    
    TriggerServerEvent('docsmarket:buyItem', data.deskId, data.itemName, data.quantity, data.price)
    
    cb('ok')
end)

RegisterNUICallback('setItemPrice', function(data, cb)
    debugPrint('Setting price for ' .. data.itemName .. ' to $' .. data.price)
    
    TriggerServerEvent('docsmarket:setItemPrice', data.deskId, data.itemName, data.price)
    
    cb('ok')
end)

RegisterNUICallback('removeFromShop', function(data, cb)
    debugPrint('Removing item from shop: ' .. data.itemName)
    
    TriggerServerEvent('docsmarket:removeFromShop', data.deskId, data.itemName)
    
    cb('ok')
end)

-- Event handlers for NUI
RegisterNetEvent('docsmarket:openShopNUI', function(shopData)
    debugPrint('Client received openShopNUI event')
    debugPrint('Shop data: ' .. json.encode(shopData))
    openShopNUI(shopData)
end)

RegisterNetEvent('docsmarket:openShopManagementNUI', function(managementData)
    debugPrint('Client received openShopManagementNUI event')
    debugPrint('Management data: ' .. json.encode(managementData))
    openShopManagementNUI(managementData)
end)

RegisterNetEvent('docsmarket:closeShopNUI', function()
    closeShopNUI()
end)

RegisterNetEvent('docsmarket:updateShopNUI', function(shopData)
    if nuiOpen then
        SendNUIMessage({
            action = 'updateShop',
            data = shopData
        })
    end
end)

-- ESC key handling is done in NUI JavaScript, not needed here

-- Purchase success/failure notifications
RegisterNetEvent('docsmarket:purchaseResult', function(success, message, newShopData)
    if success then
        showNotification(message, 'success')
        if newShopData and nuiOpen then
            SendNUIMessage({
                action = 'updateShop',
                data = newShopData
            })
        end
    else
        showNotification(message, 'error')
    end
end)

-- Price setting result
RegisterNetEvent('docsmarket:priceSetResult', function(success, message, newManagementData)
    if success then
        showNotification(message, 'success')
        if newManagementData and nuiOpen then
            SendNUIMessage({
                action = 'updateManagement',
                data = newManagementData
            })
        end
    else
        showNotification(message, 'error')
    end
end)
