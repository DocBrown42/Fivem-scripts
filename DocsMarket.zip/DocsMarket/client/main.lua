-- DocsMarket Client Main
local QBX = exports.qbx_core
local PlayerData = QBX:GetPlayerData()

-- Storage for spawned entities
local MarketDesks = {}

-- Debug function
local function debugPrint(message)
    if Config.Debug then
        print('^3[DocsMarket Debug]^7 ' .. message)
    end
end

-- Notification function
local function showNotification(message, type)
    if exports.ox_lib then
        lib.notify({
            title = 'Black Market',
            description = message,
            type = type or 'info',
            position = Config.Notifications.position,
            duration = Config.Notifications.duration
        })
    else
        TriggerEvent('chat:addMessage', {
            color = {255, 255, 255},
            multiline = true,
            args = {'Black Market', message}
        })
    end
end

-- Time formatting function
local function formatTime(seconds)
    local days = math.floor(seconds / 86400)
    local hours = math.floor((seconds % 86400) / 3600)
    local minutes = math.floor((seconds % 3600) / 60)

    if days > 0 then
        return string.format('%dd %dh', days, hours)
    elseif hours > 0 then
        return string.format('%dh %dm', hours, minutes)
    else
        return string.format('%dm', minutes)
    end
end

-- Show rental duration selection menu
local function showRentalDurationMenu(deskId)
    debugPrint('Showing rental duration menu for desk ' .. deskId)

    local options = {}

    for i, option in ipairs(Config.Operations.rentalOptions) do
        local timeStr = formatTime(option.duration)
        table.insert(options, {
            title = option.label,
            description = '$' .. option.cost .. ' for ' .. timeStr,
            icon = 'fas fa-clock',
            onSelect = function()
                local confirm = lib.alertDialog({
                    header = 'Rent Market Desk',
                    content = 'Rent this desk for $' .. option.cost .. ' for ' .. option.label .. '?',
                    centered = true,
                    cancel = true
                })

                if confirm == 'confirm' then
                    TriggerServerEvent('docsmarket:rentDesk', deskId, i)
                end
            end
        })
    end

    lib.registerContext({
        id = 'rental_duration_menu',
        title = 'Select Rental Duration',
        options = options
    })

    lib.showContext('rental_duration_menu')
end

-- Spawn market desks
local function spawnMarketDesks()
    debugPrint('Spawning market desks...')
    
    for i, desk in pairs(Config.DeskLocations) do
        local model = GetHashKey(Config.DeskProp)
        RequestModel(model)
        
        while not HasModelLoaded(model) do
            Wait(100)
        end
        
        local entity = CreateObject(model, desk.coords.x, desk.coords.y, desk.coords.z, false, false, false)
        SetEntityHeading(entity, desk.heading)
        FreezeEntityPosition(entity, true)
        
        MarketDesks[desk.id] = entity
        
        -- Add ox_target options
        exports.ox_target:addLocalEntity(entity, {
            {
                name = 'market_rent_' .. desk.id,
                label = 'Rent Market Desk',
                icon = 'fas fa-dollar-sign',
                onSelect = function()
                    showRentalDurationMenu(desk.id)
                end,
                canInteract = function()
                    local status = lib.callback.await('docsmarket:getDeskStatus', false, desk.id)
                    return status and not status.occupied
                end
            },
            {
                name = 'market_access_' .. desk.id,
                label = 'Access Stash',
                icon = 'fas fa-box',
                onSelect = function()
                    TriggerServerEvent('docsmarket:openStash', desk.id)
                end,
                canInteract = function()
                    local status = lib.callback.await('docsmarket:getDeskStatus', false, desk.id)
                    return status and status.isOwner
                end
            },
            {
                name = 'market_manage_' .. desk.id,
                label = 'Manage Shop',
                icon = 'fas fa-store',
                onSelect = function()
                    TriggerServerEvent('docsmarket:openShopManagement', desk.id)
                end,
                canInteract = function()
                    local status = lib.callback.await('docsmarket:getDeskStatus', false, desk.id)
                    return status and status.isOwner
                end
            },
            {
                name = 'market_browse_' .. desk.id,
                label = 'Browse Shop',
                icon = 'fas fa-shopping-cart',
                onSelect = function()
                    TriggerServerEvent('docsmarket:browseShop', desk.id)
                end,
                canInteract = function()
                    local status = lib.callback.await('docsmarket:getDeskStatus', false, desk.id)
                    return status and status.occupied
                end
            },
            {
                name = 'market_release_' .. desk.id,
                label = 'Release Desk',
                icon = 'fas fa-times',
                onSelect = function()
                    local confirm = lib.alertDialog({
                        header = 'Release Market Desk',
                        content = 'Are you sure you want to release this desk? Your items will be saved for recovery.',
                        centered = true,
                        cancel = true
                    })
                    
                    if confirm == 'confirm' then
                        TriggerServerEvent('docsmarket:releaseDesk', desk.id)
                    end
                end,
                canInteract = function()
                    local status = lib.callback.await('docsmarket:getDeskStatus', false, desk.id)
                    return status and status.isOwner
                end
            },
            {
                name = 'market_info_' .. desk.id,
                label = 'Desk Information',
                icon = 'fas fa-info',
                onSelect = function()
                    local status = lib.callback.await('docsmarket:getDeskStatus', false, desk.id)
                    if status then
                        local message = 'Desk #' .. desk.id .. '\n'
                        if status.occupied then
                            message = message .. 'Status: Occupied'
                            if status.isOwner then
                                message = message .. ' (by you)'
                            end
                        else
                            message = message .. 'Status: Available\n\nRental Options:'
                            for _, option in ipairs(Config.Operations.rentalOptions) do
                                local timeStr = formatTime(option.duration)
                                message = message .. '\n• ' .. option.label .. ': $' .. option.cost .. ' (' .. timeStr .. ')'
                            end
                        end
                        
                        lib.alertDialog({
                            header = 'Market Desk Information',
                            content = message,
                            centered = true
                        })
                    end
                end
            }
        })
        
        debugPrint('Spawned desk ' .. desk.id .. ' with entity ID: ' .. entity)
    end
    
    debugPrint('Finished spawning ' .. #Config.DeskLocations .. ' market desks')
end

-- Recovery NPC is now handled by client/recovery.lua

-- Event handlers
RegisterNetEvent('docsmarket:deskRented', function(deskId, duration)
    if duration then
        local timeStr = formatTime(duration)
        showNotification('Market desk #' .. deskId .. ' rented for ' .. timeStr .. '! You can now access your stash.', 'success')
    else
        showNotification('Market desk #' .. deskId .. ' rented successfully! You can now access your stash.', 'success')
    end
end)

RegisterNetEvent('docsmarket:deskReleased', function(deskId)
    showNotification('Market desk #' .. deskId .. ' released. Your items have been saved for recovery.', 'info')
end)

RegisterNetEvent('docsmarket:receiveRecoveryItems', function(items)
    if not items or not next(items) then
        showNotification('No items to recover', 'error')
        return
    end
    
    local itemList = {}
    for item, count in pairs(items) do
        table.insert(itemList, count .. 'x ' .. item)
    end
    
    lib.alertDialog({
        header = 'Item Recovery',
        content = 'Recovered items:\n' .. table.concat(itemList, '\n'),
        centered = true
    })
end)

-- Player data events
RegisterNetEvent('qbx_core:client:playerLoaded', function()
    PlayerData = QBX:GetPlayerData()
end)

RegisterNetEvent('qbx_core:client:playerLoggedOut', function()
    PlayerData = {}
end)

-- Initialize on resource start
CreateThread(function()
    Wait(2000) -- Wait for other resources to load

    spawnMarketDesks()

    debugPrint('DocsMarket client initialization completed')
end)

-- Debug commands
if Config.Debug then
    RegisterCommand('bmrespawn', function()
        debugPrint('Manual respawn triggered...')

        -- Clean up existing entities
        for deskId, entity in pairs(MarketDesks) do
            if DoesEntityExist(entity) then
                DeleteEntity(entity)
            end
        end
        MarketDesks = {}

        Wait(1000)

        -- Respawn everything
        spawnMarketDesks()

        debugPrint('Manual respawn completed')
    end, false)

    RegisterCommand('testshop', function(source, args)
        local deskId = tonumber(args[1]) or 1
        debugPrint('Testing browse shop for desk ' .. deskId)
        TriggerServerEvent('docsmarket:browseShop', deskId)
    end, false)

    RegisterCommand('testmanage', function(source, args)
        local deskId = tonumber(args[1]) or 1
        debugPrint('Testing shop management for desk ' .. deskId)
        TriggerServerEvent('docsmarket:openShopManagement', deskId)
    end, false)

    RegisterCommand('testnui', function()
        debugPrint('Testing NUI directly')
        local testData = {
            deskId = 1,
            shopName = 'Test Shop',
            items = {
                {
                    name = 'bandage',
                    label = 'Bandage',
                    count = 10,
                    price = 50,
                    image = 'nui://ox_inventory/web/images/bandage.png',
                    description = 'A medical bandage'
                }
            },
            isOwner = false
        }
        TriggerEvent('docsmarket:openShopNUI', testData)
    end, false)
end
