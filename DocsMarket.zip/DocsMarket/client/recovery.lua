-- DocsMarket Recovery NPC Client
local recoveryNPC = nil
local recoveryBlip = nil
local currentRecoveryData = nil

-- Debug function
local function debugPrint(message)
    if Config.Debug then
        print('^3[DocsMarket Recovery Debug]^7 ' .. message)
    end
end

-- Create recovery NPC
local function createRecoveryNPC()
    debugPrint('Creating recovery NPC')
    
    local model = Config.RecoveryNPC.model
    local coords = Config.RecoveryNPC.location
    
    -- Load model
    lib.requestModel(model)
    
    -- Create NPC
    recoveryNPC = CreatePed(4, model, coords.x, coords.y, coords.z, coords.w, false, true)
    SetEntityInvincible(recoveryNPC, true)
    SetBlockingOfNonTemporaryEvents(recoveryNPC, true)
    FreezeEntityPosition(recoveryNPC, true)
    
    -- Set scenario
    if Config.RecoveryNPC.scenario then
        TaskStartScenarioInPlace(recoveryNPC, Config.RecoveryNPC.scenario, 0, true)
    end
    
    debugPrint('Recovery NPC created at: ' .. coords.x .. ', ' .. coords.y .. ', ' .. coords.z)
end

-- Create recovery blip
local function createRecoveryBlip()
    if not Config.RecoveryNPC.blip then return end
    
    debugPrint('Creating recovery blip')
    
    local coords = Config.RecoveryNPC.location
    recoveryBlip = AddBlipForCoord(coords.x, coords.y, coords.z)
    
    SetBlipSprite(recoveryBlip, Config.RecoveryNPC.blip.sprite)
    SetBlipColour(recoveryBlip, Config.RecoveryNPC.blip.color)
    SetBlipScale(recoveryBlip, Config.RecoveryNPC.blip.scale)
    SetBlipAsShortRange(recoveryBlip, true)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentString(Config.RecoveryNPC.blip.label)
    EndTextCommandSetBlipName(recoveryBlip)
    
    debugPrint('Recovery blip created')
end

-- Setup recovery NPC target
local function setupRecoveryTarget()
    if not recoveryNPC then return end
    
    debugPrint('Setting up recovery NPC target')
    
    exports.ox_target:addLocalEntity(recoveryNPC, {
        {
            name = 'recovery_npc',
            icon = 'fas fa-box-open',
            label = 'Access Recovery Services',
            onSelect = function()
                debugPrint('Player interacted with recovery NPC')
                openRecoveryMenu()
            end
        }
    })
end

-- Open recovery menu
function openRecoveryMenu()
    debugPrint('Opening recovery menu')

    -- Request recovery data from server
    debugPrint('Triggering server event: docsmarket:getRecoveryData')
    TriggerServerEvent('docsmarket:getRecoveryData')
end

-- Show recovery interface
local function showRecoveryInterface(data)
    debugPrint('Showing recovery interface')
    
    if not data.hasData then
        lib.notify({
            title = 'Recovery NPC',
            description = 'You have no items or earnings to recover',
            type = 'info'
        })
        return
    end
    
    local options = {}
    
    -- Add earnings section
    if data.totalEarnings > 0 then
        table.insert(options, {
            title = 'Shop Earnings',
            description = 'Total unclaimed: $' .. data.totalEarnings,
            icon = 'fas fa-dollar-sign',
            onSelect = function()
                showEarningsMenu(data.earnings, data.totalEarnings)
            end
        })
    end
    
    -- Add recovery items section
    if #data.items > 0 then
        table.insert(options, {
            title = 'Recovery Items',
            description = #data.items .. ' item types available',
            icon = 'fas fa-box',
            onSelect = function()
                showRecoveryItemsMenu(data.items)
            end
        })
    end
    
    -- Add claim all option if both exist
    if data.totalEarnings > 0 and #data.items > 0 then
        table.insert(options, {
            title = 'Claim Everything',
            description = 'Claim all earnings and items',
            icon = 'fas fa-hand-holding-usd',
            onSelect = function()
                claimEverything()
            end
        })
    end
    
    lib.registerContext({
        id = 'recovery_main_menu',
        title = 'Black Market Recovery',
        options = options
    })
    
    lib.showContext('recovery_main_menu')
end

-- Show earnings menu
function showEarningsMenu(earnings, totalAmount)
    debugPrint('Showing earnings menu')
    
    local options = {
        {
            title = 'Claim All Earnings',
            description = 'Claim $' .. totalAmount,
            icon = 'fas fa-money-bill-wave',
            onSelect = function()
                TriggerServerEvent('docsmarket:claimAllEarnings')
            end
        }
    }
    
    -- Add individual earnings
    for _, earning in ipairs(earnings) do
        local description = 'Desk #' .. earning.deskId .. ' - $' .. earning.amount
        if earning.itemName then
            description = description .. ' (' .. earning.itemName .. ' x' .. (earning.quantity or 1) .. ')'
        end
        
        table.insert(options, {
            title = earning.transactionType == 'sale' and 'Sale Earnings' or 'Rental Refund',
            description = description,
            icon = 'fas fa-receipt',
            onSelect = function()
                TriggerServerEvent('docsmarket:claimEarnings', earning.amount)
            end
        })
    end
    
    lib.registerContext({
        id = 'recovery_earnings_menu',
        title = 'Shop Earnings',
        menu = 'recovery_main_menu',
        options = options
    })
    
    lib.showContext('recovery_earnings_menu')
end

-- Show recovery items menu
function showRecoveryItemsMenu(items)
    debugPrint('Showing recovery items menu')
    
    local options = {
        {
            title = 'Claim All Items',
            description = 'Recover all ' .. #items .. ' item types',
            icon = 'fas fa-boxes',
            onSelect = function()
                TriggerServerEvent('docsmarket:claimAllRecoveryItems')
            end
        }
    }
    
    -- Add individual items
    for _, item in ipairs(items) do
        local reasonText = item.recoveryReason == 'rental_expired' and 'Rental Expired' or 
                          item.recoveryReason == 'server_restart' and 'Server Restart' or 'Manual Release'
        
        table.insert(options, {
            title = item.itemName .. ' x' .. item.itemCount,
            description = 'From Desk #' .. item.deskId .. ' - ' .. reasonText,
            icon = 'fas fa-box',
            onSelect = function()
                TriggerServerEvent('docsmarket:claimRecoveryItems', {item.id})
            end
        })
    end
    
    lib.registerContext({
        id = 'recovery_items_menu',
        title = 'Recovery Items',
        menu = 'recovery_main_menu',
        options = options
    })
    
    lib.showContext('recovery_items_menu')
end

-- Claim everything
function claimEverything()
    debugPrint('Claiming everything')
    
    local alert = lib.alertDialog({
        header = 'Claim Everything',
        content = 'Are you sure you want to claim all earnings and items? Make sure you have enough inventory space.',
        centered = true,
        cancel = true
    })
    
    if alert == 'confirm' then
        TriggerServerEvent('docsmarket:claimAllEarnings')
        Wait(500) -- Small delay
        TriggerServerEvent('docsmarket:claimAllRecoveryItems')
    end
end

-- Event handlers
RegisterNetEvent('docsmarket:receiveRecoveryData', function(data)
    debugPrint('=== RECEIVED RECOVERY DATA ===')
    debugPrint('Data: ' .. json.encode(data))
    currentRecoveryData = data
    showRecoveryInterface(data)
end)

-- Initialize recovery system
CreateThread(function()
    Wait(2000) -- Wait for other systems to load
    
    debugPrint('Initializing recovery NPC system')
    
    createRecoveryNPC()
    createRecoveryBlip()
    setupRecoveryTarget()
    
    debugPrint('Recovery NPC system initialized')
end)

-- Cleanup on resource stop
AddEventHandler('onResourceStop', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        if recoveryNPC then
            DeleteEntity(recoveryNPC)
        end
        if recoveryBlip then
            RemoveBlip(recoveryBlip)
        end
    end
end)
