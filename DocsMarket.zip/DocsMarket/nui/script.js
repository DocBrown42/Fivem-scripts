// DocsMarket NUI Script
let currentShopData = null;
let currentManagementData = null;
let currentItem = null;

// DOM Elements
const app = document.getElementById('app');
const shopContainer = document.getElementById('shopContainer');
const managementContainer = document.getElementById('managementContainer');
const purchaseModal = document.getElementById('purchaseModal');
const priceModal = document.getElementById('priceModal');

// Initialize event listeners
document.addEventListener('DOMContentLoaded', function() {
    // Close buttons
    document.getElementById('closeBtn').addEventListener('click', closeShop);
    document.getElementById('closeManagementBtn').addEventListener('click', closeShop);
    document.getElementById('closePurchaseModal').addEventListener('click', closePurchaseModal);
    document.getElementById('closePriceModal').addEventListener('click', closePriceModal);
    
    // Purchase modal
    document.getElementById('decreaseQty').addEventListener('click', decreaseQuantity);
    document.getElementById('increaseQty').addEventListener('click', increaseQuantity);
    document.getElementById('purchaseQuantity').addEventListener('input', updatePurchaseTotal);
    document.getElementById('confirmPurchase').addEventListener('click', confirmPurchase);
    document.getElementById('cancelPurchase').addEventListener('click', closePurchaseModal);
    
    // Price modal
    document.getElementById('addToShop').addEventListener('click', addToShop);
    document.getElementById('removeFromShop').addEventListener('click', removeFromShop);
    document.getElementById('cancelPrice').addEventListener('click', closePriceModal);
    
    // ESC key handler
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            if (purchaseModal.style.display !== 'none') {
                closePurchaseModal();
            } else if (priceModal.style.display !== 'none') {
                closePriceModal();
            } else {
                closeShop();
            }
        }
    });

    // Enhanced scrolling for content areas
    setupSmoothScrolling();
});

// Setup smooth scrolling functionality
function setupSmoothScrolling() {
    const contentAreas = document.querySelectorAll('.content');

    contentAreas.forEach(content => {
        // Add scroll indicators
        addScrollIndicators(content);

        // Update scroll indicators on scroll (native scrolling)
        content.addEventListener('scroll', function() {
            updateScrollIndicators(content);
        });

        // Add manual scroll capability with wheel events
        content.addEventListener('wheel', function(e) {
            console.log('[DocsMarket Scroll] Wheel event detected, deltaY:', e.deltaY);

            // Prevent default to override browser scrolling
            e.preventDefault();

            // Option 1: Fast pixel scrolling (multiply by 6 for very fast scrolling)
            const scrollMultiplier = 6;
            let scrollAmount = e.deltaY * scrollMultiplier;

            // Option 2: Scroll by item rows (uncomment for even faster scrolling)
            // const itemHeight = 200; // Approximate height of item card + gap
            // scrollAmount = e.deltaY > 0 ? itemHeight : -itemHeight;

            // Apply smooth scrolling with faster speed
            content.scrollBy({
                top: scrollAmount,
                behavior: 'smooth'
            });

            console.log('[DocsMarket Scroll] Fast scroll applied, amount:', scrollAmount);
        }, { passive: false });

        // Log scroll capabilities for debugging
        setTimeout(() => {
            const isScrollable = content.scrollHeight > content.clientHeight;
            console.log('[DocsMarket Scroll] Content area setup:', {
                scrollHeight: content.scrollHeight,
                clientHeight: content.clientHeight,
                isScrollable: isScrollable
            });

            // Initial indicator update
            updateScrollIndicators(content);
        }, 100);
    });
}

// Add visual scroll indicators
function addScrollIndicators(content) {
    // Create scroll indicator container
    const indicatorContainer = document.createElement('div');
    indicatorContainer.className = 'scroll-indicators';

    // Top indicator (fade in)
    const topIndicator = document.createElement('div');
    topIndicator.className = 'scroll-indicator scroll-indicator-top';
    topIndicator.innerHTML = '<i class="fas fa-chevron-up"></i>';

    // Bottom indicator (fade out)
    const bottomIndicator = document.createElement('div');
    bottomIndicator.className = 'scroll-indicator scroll-indicator-bottom';
    bottomIndicator.innerHTML = '<i class="fas fa-chevron-down"></i>';

    indicatorContainer.appendChild(topIndicator);
    indicatorContainer.appendChild(bottomIndicator);

    // Add to content's parent container
    const container = content.closest('.container');
    if (container) {
        container.appendChild(indicatorContainer);
    }
}

// Update scroll indicator visibility
function updateScrollIndicators(content) {
    const container = content.closest('.container');
    if (!container) return;

    const topIndicator = container.querySelector('.scroll-indicator-top');
    const bottomIndicator = container.querySelector('.scroll-indicator-bottom');

    if (!topIndicator || !bottomIndicator) return;

    const scrollTop = content.scrollTop;
    const scrollHeight = content.scrollHeight;
    const clientHeight = content.clientHeight;
    const scrollBottom = scrollHeight - clientHeight - scrollTop;

    console.log('[DocsMarket Scroll] Scroll info:', {
        scrollTop,
        scrollHeight,
        clientHeight,
        scrollBottom,
        isScrollable: scrollHeight > clientHeight
    });

    // Show/hide top indicator
    if (scrollTop > 20) {
        topIndicator.style.opacity = '1';
        console.log('[DocsMarket Scroll] Showing top indicator');
    } else {
        topIndicator.style.opacity = '0';
    }

    // Show/hide bottom indicator
    if (scrollBottom > 20) {
        bottomIndicator.style.opacity = '1';
        console.log('[DocsMarket Scroll] Showing bottom indicator');
    } else {
        bottomIndicator.style.opacity = '0';
    }
}

// Message handler from Lua
window.addEventListener('message', function(event) {
    const data = event.data;

    console.log('[DocsMarket NUI] Received message:', data.action);

    switch(data.action) {
        case 'openShop':
            console.log('[DocsMarket NUI] Opening shop with data:', data.data);
            openShop(data.data);
            break;
        case 'openManagement':
            console.log('[DocsMarket NUI] Opening management with data:', data.data);
            openManagement(data.data);
            break;
        case 'closeShop':
            console.log('[DocsMarket NUI] Received close shop message');
            if (app.style.display !== 'none') {
                closeShop();
            } else {
                console.log('[DocsMarket NUI] Already closed, ignoring close message');
            }
            break;
        case 'updateShop':
            console.log('[DocsMarket NUI] Updating shop data:', data.data);
            updateShop(data.data);
            break;
        case 'updateManagement':
            console.log('[DocsMarket NUI] Updating management data:', data.data);
            updateManagement(data.data);
            break;
    }
});

// Open shop interface
function openShop(shopData) {
    console.log('[DocsMarket NUI] === OPENING SHOP INTERFACE ===');
    console.log('[DocsMarket NUI] Data received:', shopData);
    console.log('[DocsMarket NUI] Current app display:', app.style.display);
    console.log('[DocsMarket NUI] Current shop display:', shopContainer.style.display);

    currentShopData = shopData;

    // Force close everything first
    app.style.display = 'none';
    shopContainer.style.display = 'none';
    managementContainer.style.display = 'none';
    closePurchaseModal();
    closePriceModal();

    // Small delay to ensure cleanup
    setTimeout(() => {
        console.log('[DocsMarket NUI] Setting up shop interface...');

        document.getElementById('shopTitle').textContent = shopData.shopName;

        const itemsGrid = document.getElementById('itemsGrid');
        const emptyMessage = document.getElementById('emptyMessage');

        // Clear existing content
        itemsGrid.innerHTML = '';

        if (shopData.items.length === 0) {
            itemsGrid.style.display = 'none';
            emptyMessage.style.display = 'block';
            console.log('[DocsMarket NUI] No items to display');
        } else {
            itemsGrid.style.display = 'grid';
            emptyMessage.style.display = 'none';
            console.log('[DocsMarket NUI] Rendering', shopData.items.length, 'items');
            renderShopItems(shopData.items);
        }

        // Show shop interface
        shopContainer.style.display = 'block';
        managementContainer.style.display = 'none';
        app.style.display = 'flex';

        console.log('[DocsMarket NUI] Shop interface fully opened');
        console.log('[DocsMarket NUI] Final app display:', app.style.display);
        console.log('[DocsMarket NUI] Final shop display:', shopContainer.style.display);
    }, 100);
}

// Open management interface
function openManagement(managementData) {
    console.log('[DocsMarket NUI] === OPENING MANAGEMENT INTERFACE ===');
    console.log('[DocsMarket NUI] Data received:', managementData);
    console.log('[DocsMarket NUI] Current app display:', app.style.display);
    console.log('[DocsMarket NUI] Current management display:', managementContainer.style.display);

    currentManagementData = managementData;

    // Force close everything first
    app.style.display = 'none';
    shopContainer.style.display = 'none';
    managementContainer.style.display = 'none';
    closePurchaseModal();
    closePriceModal();

    // Small delay to ensure cleanup
    setTimeout(() => {
        console.log('[DocsMarket NUI] Setting up management interface...');

        document.getElementById('managementTitle').textContent = managementData.shopName;

        const managementGrid = document.getElementById('managementGrid');
        const emptyManagementMessage = document.getElementById('emptyManagementMessage');

        // Clear existing content
        managementGrid.innerHTML = '';

        if (managementData.items.length === 0) {
            managementGrid.style.display = 'none';
            emptyManagementMessage.style.display = 'block';
            console.log('[DocsMarket NUI] No items to display');
        } else {
            managementGrid.style.display = 'grid';
            emptyManagementMessage.style.display = 'none';
            console.log('[DocsMarket NUI] Rendering', managementData.items.length, 'items');
            renderManagementItems(managementData.items);
        }

        // Show management interface
        shopContainer.style.display = 'none';
        managementContainer.style.display = 'block';
        app.style.display = 'flex';

        // Initialize scroll indicators for the management interface
        setTimeout(() => {
            const managementContent = managementContainer.querySelector('.content');
            if (managementContent) {
                // Remove existing indicators first
                const existingIndicators = managementContainer.querySelector('.scroll-indicators');
                if (existingIndicators) {
                    existingIndicators.remove();
                }

                // Add new scroll indicators
                addScrollIndicators(managementContent);

                // Force a scroll check after content is rendered
                setTimeout(() => {
                    console.log('[DocsMarket Scroll] Final scroll check after management opened');

                    // Force layout recalculation
                    managementContent.style.height = 'auto';
                    managementContent.offsetHeight; // Trigger reflow
                    managementContent.style.height = '';

                    updateScrollIndicators(managementContent);

                    // Test scrolling capability with multiple checks
                    const scrollHeight = managementContent.scrollHeight;
                    const clientHeight = managementContent.clientHeight;
                    const offsetHeight = managementContent.offsetHeight;
                    const isScrollable = scrollHeight > clientHeight;

                    console.log('[DocsMarket Scroll] Detailed scroll info:', {
                        scrollHeight,
                        clientHeight,
                        offsetHeight,
                        isScrollable,
                        difference: scrollHeight - clientHeight
                    });

                    // Force scrollable if content is close to overflowing
                    const threshold = 10; // pixels
                    const forceScrollable = (scrollHeight - clientHeight) >= -threshold;

                    if (isScrollable || forceScrollable) {
                        console.log('[DocsMarket Scroll] Content is scrollable - enabling scroll');
                        // Force scroll indicators to show
                        const bottomIndicator = managementContainer.querySelector('.scroll-indicator-bottom');
                        if (bottomIndicator) {
                            bottomIndicator.style.opacity = '1';
                        }
                    } else {
                        console.log('[DocsMarket Scroll] Content is NOT scrollable - all items fit in view');
                    }
                }, 300);
            }
        }, 50);

        console.log('[DocsMarket NUI] Management interface fully opened');
        console.log('[DocsMarket NUI] Final app display:', app.style.display);
        console.log('[DocsMarket NUI] Final management display:', managementContainer.style.display);
    }, 100);
}

// Close shop
let isClosing = false;
function closeShop() {
    console.log('[DocsMarket NUI] closeShop called');

    // Prevent recursive closing
    if (isClosing) {
        console.log('[DocsMarket NUI] Already closing, ignoring');
        return;
    }

    if (app.style.display === 'none') {
        console.log('[DocsMarket NUI] Already closed, ignoring');
        return;
    }

    isClosing = true;

    app.style.display = 'none';
    closePurchaseModal();
    closePriceModal();

    // Reset data
    currentShopData = null;
    currentManagementData = null;
    currentItem = null;

    // Send close message to Lua
    fetch(`https://${GetParentResourceName()}/closeShop`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    }).finally(() => {
        isClosing = false;
    });
}

// Render shop items
function renderShopItems(items) {
    const itemsGrid = document.getElementById('itemsGrid');
    itemsGrid.innerHTML = '';
    
    items.forEach(item => {
        const itemCard = document.createElement('div');
        itemCard.className = 'item-card';
        itemCard.innerHTML = `
            <img src="${item.image}" alt="${item.label}" class="item-image" onerror="this.src='nui://ox_inventory/web/images/placeholder.png'">
            <div class="item-name">${item.label}</div>
            <div class="item-description">${item.description}</div>
            <div class="item-details">
                <span class="item-count">${item.count} available</span>
                <span class="item-price">$${item.price}</span>
            </div>
            <div class="item-actions">
                <button class="btn btn-primary" onclick="openPurchaseModal('${item.name}')">
                    <i class="fas fa-shopping-cart"></i> Buy
                </button>
            </div>
        `;
        itemsGrid.appendChild(itemCard);
    });
}

// Render management items
function renderManagementItems(items) {
    const managementGrid = document.getElementById('managementGrid');
    managementGrid.innerHTML = '';
    
    items.forEach(item => {
        const itemCard = document.createElement('div');
        itemCard.className = 'item-card';
        
        const statusClass = item.inShop ? 'in-shop' : 'not-in-shop';
        const statusText = item.inShop ? 'In Shop' : 'Not in Shop';
        
        itemCard.innerHTML = `
            <img src="${item.image}" alt="${item.label}" class="item-image" onerror="this.src='nui://ox_inventory/web/images/placeholder.png'">
            <div class="item-name">
                ${item.label}
                <span class="shop-status ${statusClass}">${statusText}</span>
            </div>
            <div class="item-description">${item.description}</div>
            <div class="item-details">
                <span class="item-count">${item.count} in stash</span>
                <span class="item-price">$${item.price || 0}</span>
            </div>
            <div class="item-actions">
                <button class="btn btn-primary" onclick="openPriceModal('${item.name}')">
                    <i class="fas fa-dollar-sign"></i> Manage
                </button>
            </div>
        `;
        managementGrid.appendChild(itemCard);
    });
}

// Open purchase modal
function openPurchaseModal(itemName) {
    const item = currentShopData.items.find(i => i.name === itemName);
    if (!item) return;
    
    currentItem = item;
    
    document.getElementById('purchaseItemImage').src = item.image;
    document.getElementById('purchaseItemName').textContent = item.label;
    document.getElementById('purchaseItemDescription').textContent = item.description;
    document.getElementById('purchaseAvailable').textContent = item.count;
    document.getElementById('purchasePriceEach').textContent = `$${item.price}`;
    
    const quantityInput = document.getElementById('purchaseQuantity');
    quantityInput.max = item.count;
    quantityInput.value = 1;
    
    updatePurchaseTotal();
    purchaseModal.style.display = 'flex';
}

// Close purchase modal
function closePurchaseModal() {
    purchaseModal.style.display = 'none';
    currentItem = null;
}

// Open price modal
function openPriceModal(itemName) {
    const item = currentManagementData.items.find(i => i.name === itemName);
    if (!item) return;
    
    currentItem = item;
    
    document.getElementById('priceItemImage').src = item.image;
    document.getElementById('priceItemName').textContent = item.label;
    document.getElementById('priceItemDescription').textContent = item.description;
    document.getElementById('priceAvailable').textContent = item.count;
    
    const priceInput = document.getElementById('itemPrice');
    priceInput.value = item.price > 0 ? item.price : '';
    
    priceModal.style.display = 'flex';
}

// Close price modal
function closePriceModal() {
    priceModal.style.display = 'none';
    currentItem = null;
}

// Quantity controls
function decreaseQuantity() {
    const quantityInput = document.getElementById('purchaseQuantity');
    const currentValue = parseInt(quantityInput.value);
    if (currentValue > 1) {
        quantityInput.value = currentValue - 1;
        updatePurchaseTotal();
    }
}

function increaseQuantity() {
    const quantityInput = document.getElementById('purchaseQuantity');
    const currentValue = parseInt(quantityInput.value);
    const maxValue = parseInt(quantityInput.max);
    if (currentValue < maxValue) {
        quantityInput.value = currentValue + 1;
        updatePurchaseTotal();
    }
}

// Update purchase total
function updatePurchaseTotal() {
    if (!currentItem) return;
    
    const quantity = parseInt(document.getElementById('purchaseQuantity').value) || 1;
    const total = currentItem.price * quantity;
    document.getElementById('purchaseTotal').textContent = `$${total}`;
}

// Confirm purchase
function confirmPurchase() {
    if (!currentItem || !currentShopData) return;
    
    const quantity = parseInt(document.getElementById('purchaseQuantity').value) || 1;
    
    fetch(`https://${GetParentResourceName()}/buyItem`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            deskId: currentShopData.deskId,
            itemName: currentItem.name,
            quantity: quantity,
            price: currentItem.price
        })
    });
    
    closePurchaseModal();
}

// Add to shop
function addToShop() {
    if (!currentItem || !currentManagementData) return;
    
    const price = parseInt(document.getElementById('itemPrice').value);
    if (!price || price < 1) {
        alert('Please enter a valid price');
        return;
    }
    
    fetch(`https://${GetParentResourceName()}/setItemPrice`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            deskId: currentManagementData.deskId,
            itemName: currentItem.name,
            price: price
        })
    });
    
    closePriceModal();
}

// Remove from shop
function removeFromShop() {
    if (!currentItem || !currentManagementData) return;
    
    fetch(`https://${GetParentResourceName()}/removeFromShop`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            deskId: currentManagementData.deskId,
            itemName: currentItem.name
        })
    });
    
    closePriceModal();
}

// Update shop data
function updateShop(shopData) {
    currentShopData = shopData;
    if (shopContainer.style.display !== 'none') {
        renderShopItems(shopData.items);
    }
}

// Update management data
function updateManagement(managementData) {
    currentManagementData = managementData;
    if (managementContainer.style.display !== 'none') {
        renderManagementItems(managementData.items);

        // Update scroll indicators after content changes
        setTimeout(() => {
            const managementContent = managementContainer.querySelector('.content');
            if (managementContent) {
                updateScrollIndicators(managementContent);
            }
        }, 50);
    }
}
